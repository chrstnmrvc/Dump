	window.widgets = {
		descriptionMap : widgetDescriptionMap = {},
		rootWidgetMap : widgetRootMap = {}
	};

	widgets.descriptionMap[["s-Path_6", "e746042c-5631-4455-a5a1-803d4dd10030"]] = ""; 

			widgets.rootWidgetMap[["s-Path_6", "e746042c-5631-4455-a5a1-803d4dd10030"]] = ["Twitter", "s-Path_6"]; 

	widgets.descriptionMap[["s-Path_7", "e746042c-5631-4455-a5a1-803d4dd10030"]] = ""; 

			widgets.rootWidgetMap[["s-Path_7", "e746042c-5631-4455-a5a1-803d4dd10030"]] = ["YouTube", "s-Path_7"]; 

	widgets.descriptionMap[["s-Path_15", "e746042c-5631-4455-a5a1-803d4dd10030"]] = ""; 

			widgets.rootWidgetMap[["s-Path_15", "e746042c-5631-4455-a5a1-803d4dd10030"]] = ["Mail", "s-Path_15"]; 

	widgets.descriptionMap[["s-Image_8", "e746042c-5631-4455-a5a1-803d4dd10030"]] = ""; 

			widgets.rootWidgetMap[["s-Image_8", "e746042c-5631-4455-a5a1-803d4dd10030"]] = ["Image", "s-Image_8"]; 

	widgets.descriptionMap[["s-Button_1", "e746042c-5631-4455-a5a1-803d4dd10030"]] = ""; 

			widgets.rootWidgetMap[["s-Button_1", "e746042c-5631-4455-a5a1-803d4dd10030"]] = ["Basic button", "s-Button_1"]; 

	widgets.descriptionMap[["s-Button_2", "e746042c-5631-4455-a5a1-803d4dd10030"]] = ""; 

			widgets.rootWidgetMap[["s-Button_2", "e746042c-5631-4455-a5a1-803d4dd10030"]] = ["Basic button", "s-Button_2"]; 

	widgets.descriptionMap[["s-Button_3", "e746042c-5631-4455-a5a1-803d4dd10030"]] = ""; 

			widgets.rootWidgetMap[["s-Button_3", "e746042c-5631-4455-a5a1-803d4dd10030"]] = ["Basic button", "s-Button_3"]; 

	widgets.descriptionMap[["s-Button_4", "e746042c-5631-4455-a5a1-803d4dd10030"]] = ""; 

			widgets.rootWidgetMap[["s-Button_4", "e746042c-5631-4455-a5a1-803d4dd10030"]] = ["Basic button", "s-Button_4"]; 

	widgets.descriptionMap[["s-Button_5", "e746042c-5631-4455-a5a1-803d4dd10030"]] = ""; 

			widgets.rootWidgetMap[["s-Button_5", "e746042c-5631-4455-a5a1-803d4dd10030"]] = ["Basic button", "s-Button_5"]; 

	widgets.descriptionMap[["s-Path_6", "c9e9c56b-b4cb-4115-8654-67f5e08f41ef"]] = ""; 

			widgets.rootWidgetMap[["s-Path_6", "c9e9c56b-b4cb-4115-8654-67f5e08f41ef"]] = ["Twitter", "s-Path_6"]; 

	widgets.descriptionMap[["s-Path_7", "c9e9c56b-b4cb-4115-8654-67f5e08f41ef"]] = ""; 

			widgets.rootWidgetMap[["s-Path_7", "c9e9c56b-b4cb-4115-8654-67f5e08f41ef"]] = ["YouTube", "s-Path_7"]; 

	widgets.descriptionMap[["s-Path_15", "c9e9c56b-b4cb-4115-8654-67f5e08f41ef"]] = ""; 

			widgets.rootWidgetMap[["s-Path_15", "c9e9c56b-b4cb-4115-8654-67f5e08f41ef"]] = ["Mail", "s-Path_15"]; 

	widgets.descriptionMap[["s-Button_2", "c9e9c56b-b4cb-4115-8654-67f5e08f41ef"]] = ""; 

			widgets.rootWidgetMap[["s-Button_2", "c9e9c56b-b4cb-4115-8654-67f5e08f41ef"]] = ["Basic button", "s-Button_2"]; 

	widgets.descriptionMap[["s-Button_3", "c9e9c56b-b4cb-4115-8654-67f5e08f41ef"]] = ""; 

			widgets.rootWidgetMap[["s-Button_3", "c9e9c56b-b4cb-4115-8654-67f5e08f41ef"]] = ["Basic button", "s-Button_3"]; 

	widgets.descriptionMap[["s-Button_4", "c9e9c56b-b4cb-4115-8654-67f5e08f41ef"]] = ""; 

			widgets.rootWidgetMap[["s-Button_4", "c9e9c56b-b4cb-4115-8654-67f5e08f41ef"]] = ["Basic button", "s-Button_4"]; 

	widgets.descriptionMap[["s-Button_5", "c9e9c56b-b4cb-4115-8654-67f5e08f41ef"]] = ""; 

			widgets.rootWidgetMap[["s-Button_5", "c9e9c56b-b4cb-4115-8654-67f5e08f41ef"]] = ["Basic button", "s-Button_5"]; 

	widgets.descriptionMap[["s-Button_6", "c9e9c56b-b4cb-4115-8654-67f5e08f41ef"]] = ""; 

			widgets.rootWidgetMap[["s-Button_6", "c9e9c56b-b4cb-4115-8654-67f5e08f41ef"]] = ["Basic button", "s-Button_6"]; 

	widgets.descriptionMap[["s-Path_6", "1d08b623-ad84-45c1-933a-cca98249fc81"]] = ""; 

			widgets.rootWidgetMap[["s-Path_6", "1d08b623-ad84-45c1-933a-cca98249fc81"]] = ["Twitter", "s-Path_6"]; 

	widgets.descriptionMap[["s-Path_7", "1d08b623-ad84-45c1-933a-cca98249fc81"]] = ""; 

			widgets.rootWidgetMap[["s-Path_7", "1d08b623-ad84-45c1-933a-cca98249fc81"]] = ["YouTube", "s-Path_7"]; 

	widgets.descriptionMap[["s-Path_15", "1d08b623-ad84-45c1-933a-cca98249fc81"]] = ""; 

			widgets.rootWidgetMap[["s-Path_15", "1d08b623-ad84-45c1-933a-cca98249fc81"]] = ["Mail", "s-Path_15"]; 

	widgets.descriptionMap[["s-Path_1", "1d08b623-ad84-45c1-933a-cca98249fc81"]] = ""; 

			widgets.rootWidgetMap[["s-Path_1", "1d08b623-ad84-45c1-933a-cca98249fc81"]] = ["Map", "s-Path_1"]; 

	widgets.descriptionMap[["s-Path_3", "1d08b623-ad84-45c1-933a-cca98249fc81"]] = ""; 

			widgets.rootWidgetMap[["s-Path_3", "1d08b623-ad84-45c1-933a-cca98249fc81"]] = ["Share", "s-Path_3"]; 

	widgets.descriptionMap[["s-Path_16", "1d08b623-ad84-45c1-933a-cca98249fc81"]] = ""; 

			widgets.rootWidgetMap[["s-Path_16", "1d08b623-ad84-45c1-933a-cca98249fc81"]] = ["Code", "s-Path_16"]; 

	widgets.descriptionMap[["s-Path_17", "1d08b623-ad84-45c1-933a-cca98249fc81"]] = ""; 

			widgets.rootWidgetMap[["s-Path_17", "1d08b623-ad84-45c1-933a-cca98249fc81"]] = ["Thumbs up-down", "s-Path_17"]; 

	widgets.descriptionMap[["s-Path_18", "1d08b623-ad84-45c1-933a-cca98249fc81"]] = ""; 

			widgets.rootWidgetMap[["s-Path_18", "1d08b623-ad84-45c1-933a-cca98249fc81"]] = ["User", "s-Path_18"]; 

	widgets.descriptionMap[["s-Path_19", "1d08b623-ad84-45c1-933a-cca98249fc81"]] = ""; 

			widgets.rootWidgetMap[["s-Path_19", "1d08b623-ad84-45c1-933a-cca98249fc81"]] = ["Contacts", "s-Path_19"]; 

	widgets.descriptionMap[["s-Path_20", "1d08b623-ad84-45c1-933a-cca98249fc81"]] = ""; 

			widgets.rootWidgetMap[["s-Path_20", "1d08b623-ad84-45c1-933a-cca98249fc81"]] = ["Play circle", "s-Path_20"]; 

	widgets.descriptionMap[["s-Path_21", "1d08b623-ad84-45c1-933a-cca98249fc81"]] = ""; 

			widgets.rootWidgetMap[["s-Path_21", "1d08b623-ad84-45c1-933a-cca98249fc81"]] = ["Archive", "s-Path_21"]; 

	widgets.descriptionMap[["s-Button_1", "1d08b623-ad84-45c1-933a-cca98249fc81"]] = ""; 

			widgets.rootWidgetMap[["s-Button_1", "1d08b623-ad84-45c1-933a-cca98249fc81"]] = ["Basic button", "s-Button_1"]; 

	widgets.descriptionMap[["s-Button_2", "1d08b623-ad84-45c1-933a-cca98249fc81"]] = ""; 

			widgets.rootWidgetMap[["s-Button_2", "1d08b623-ad84-45c1-933a-cca98249fc81"]] = ["Basic button", "s-Button_2"]; 

	widgets.descriptionMap[["s-Button_3", "1d08b623-ad84-45c1-933a-cca98249fc81"]] = ""; 

			widgets.rootWidgetMap[["s-Button_3", "1d08b623-ad84-45c1-933a-cca98249fc81"]] = ["Basic button", "s-Button_3"]; 

	widgets.descriptionMap[["s-Button_4", "1d08b623-ad84-45c1-933a-cca98249fc81"]] = ""; 

			widgets.rootWidgetMap[["s-Button_4", "1d08b623-ad84-45c1-933a-cca98249fc81"]] = ["Basic button", "s-Button_4"]; 

	widgets.descriptionMap[["s-Button_5", "1d08b623-ad84-45c1-933a-cca98249fc81"]] = ""; 

			widgets.rootWidgetMap[["s-Button_5", "1d08b623-ad84-45c1-933a-cca98249fc81"]] = ["Basic button", "s-Button_5"]; 

	widgets.descriptionMap[["s-Button_6", "1d08b623-ad84-45c1-933a-cca98249fc81"]] = ""; 

			widgets.rootWidgetMap[["s-Button_6", "1d08b623-ad84-45c1-933a-cca98249fc81"]] = ["Basic button", "s-Button_6"]; 

	widgets.descriptionMap[["s-Button_7", "1d08b623-ad84-45c1-933a-cca98249fc81"]] = ""; 

			widgets.rootWidgetMap[["s-Button_7", "1d08b623-ad84-45c1-933a-cca98249fc81"]] = ["Basic button", "s-Button_7"]; 

	widgets.descriptionMap[["s-Button_8", "1d08b623-ad84-45c1-933a-cca98249fc81"]] = ""; 

			widgets.rootWidgetMap[["s-Button_8", "1d08b623-ad84-45c1-933a-cca98249fc81"]] = ["Basic button", "s-Button_8"]; 

	widgets.descriptionMap[["s-Button_9", "1d08b623-ad84-45c1-933a-cca98249fc81"]] = ""; 

			widgets.rootWidgetMap[["s-Button_9", "1d08b623-ad84-45c1-933a-cca98249fc81"]] = ["Basic button", "s-Button_9"]; 

	widgets.descriptionMap[["s-Button_10", "1d08b623-ad84-45c1-933a-cca98249fc81"]] = ""; 

			widgets.rootWidgetMap[["s-Button_10", "1d08b623-ad84-45c1-933a-cca98249fc81"]] = ["Basic button", "s-Button_10"]; 

	widgets.descriptionMap[["s-Path_6", "d95a20ca-2770-41ad-bd0c-419dd9037510"]] = ""; 

			widgets.rootWidgetMap[["s-Path_6", "d95a20ca-2770-41ad-bd0c-419dd9037510"]] = ["Twitter", "s-Path_6"]; 

	widgets.descriptionMap[["s-Path_7", "d95a20ca-2770-41ad-bd0c-419dd9037510"]] = ""; 

			widgets.rootWidgetMap[["s-Path_7", "d95a20ca-2770-41ad-bd0c-419dd9037510"]] = ["YouTube", "s-Path_7"]; 

	widgets.descriptionMap[["s-Path_15", "d95a20ca-2770-41ad-bd0c-419dd9037510"]] = ""; 

			widgets.rootWidgetMap[["s-Path_15", "d95a20ca-2770-41ad-bd0c-419dd9037510"]] = ["Mail", "s-Path_15"]; 

	widgets.descriptionMap[["s-Button_1", "d95a20ca-2770-41ad-bd0c-419dd9037510"]] = ""; 

			widgets.rootWidgetMap[["s-Button_1", "d95a20ca-2770-41ad-bd0c-419dd9037510"]] = ["Basic button", "s-Button_1"]; 

	widgets.descriptionMap[["s-Button_2", "d95a20ca-2770-41ad-bd0c-419dd9037510"]] = ""; 

			widgets.rootWidgetMap[["s-Button_2", "d95a20ca-2770-41ad-bd0c-419dd9037510"]] = ["Basic button", "s-Button_2"]; 

	widgets.descriptionMap[["s-Button_3", "d95a20ca-2770-41ad-bd0c-419dd9037510"]] = ""; 

			widgets.rootWidgetMap[["s-Button_3", "d95a20ca-2770-41ad-bd0c-419dd9037510"]] = ["Basic button", "s-Button_3"]; 

	widgets.descriptionMap[["s-Button_4", "d95a20ca-2770-41ad-bd0c-419dd9037510"]] = ""; 

			widgets.rootWidgetMap[["s-Button_4", "d95a20ca-2770-41ad-bd0c-419dd9037510"]] = ["Basic button", "s-Button_4"]; 

	widgets.descriptionMap[["s-Button_5", "d95a20ca-2770-41ad-bd0c-419dd9037510"]] = ""; 

			widgets.rootWidgetMap[["s-Button_5", "d95a20ca-2770-41ad-bd0c-419dd9037510"]] = ["Basic button", "s-Button_5"]; 

	widgets.descriptionMap[["s-Input_15", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Input_15", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["Search", "s-Group_2"]; 

	widgets.descriptionMap[["s-Path_1", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Path_1", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["Search", "s-Group_2"]; 

	widgets.descriptionMap[["s-Button_6", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Button_6", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["Basic button", "s-Button_6"]; 

	widgets.descriptionMap[["s-Button_7", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Button_7", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["Basic button", "s-Button_7"]; 

	widgets.descriptionMap[["s-Button_8", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Button_8", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["Basic button", "s-Button_8"]; 

	widgets.descriptionMap[["s-Button_10", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Button_10", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["Basic button", "s-Button_10"]; 

	widgets.descriptionMap[["s-Button_11", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Button_11", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["Basic button", "s-Button_11"]; 

	widgets.descriptionMap[["s-Path_6", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Path_6", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["Twitter", "s-Path_6"]; 

	widgets.descriptionMap[["s-Path_7", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Path_7", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["YouTube", "s-Path_7"]; 

	widgets.descriptionMap[["s-Path_15", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Path_15", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["Mail", "s-Path_15"]; 

	widgets.descriptionMap[["s-Ellipse_12", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Ellipse_12", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["Circle", "s-Ellipse_12"]; 

	widgets.descriptionMap[["s-Ellipse_13", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Ellipse_13", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["Circle", "s-Ellipse_13"]; 

	widgets.descriptionMap[["s-Ellipse_14", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Ellipse_14", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["Circle", "s-Ellipse_14"]; 

	widgets.descriptionMap[["s-Ellipse_15", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Ellipse_15", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["Circle", "s-Ellipse_15"]; 

	widgets.descriptionMap[["s-Ellipse_18", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Ellipse_18", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["Circle", "s-Ellipse_18"]; 

	widgets.descriptionMap[["s-Ellipse_19", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Ellipse_19", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["Circle", "s-Ellipse_19"]; 

	widgets.descriptionMap[["s-Ellipse_20", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Ellipse_20", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["Circle", "s-Ellipse_20"]; 

	widgets.descriptionMap[["s-Ellipse_21", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Ellipse_21", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["Circle", "s-Ellipse_21"]; 

	widgets.descriptionMap[["s-Ellipse_1", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Ellipse_1", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["Circle", "s-Ellipse_1"]; 

	widgets.descriptionMap[["s-Ellipse_22", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Ellipse_22", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["Circle", "s-Ellipse_22"]; 

	widgets.descriptionMap[["s-Ellipse_23", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Ellipse_23", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["Circle", "s-Ellipse_23"]; 

	widgets.descriptionMap[["s-Ellipse_24", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Ellipse_24", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["Circle", "s-Ellipse_24"]; 

	widgets.descriptionMap[["s-Ellipse_25", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Ellipse_25", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["Circle", "s-Ellipse_25"]; 

	widgets.descriptionMap[["s-Ellipse_26", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Ellipse_26", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["Circle", "s-Ellipse_26"]; 

	widgets.descriptionMap[["s-Ellipse_27", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Ellipse_27", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["Circle", "s-Ellipse_27"]; 

	widgets.descriptionMap[["s-Ellipse_28", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Ellipse_28", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["Circle", "s-Ellipse_28"]; 

	
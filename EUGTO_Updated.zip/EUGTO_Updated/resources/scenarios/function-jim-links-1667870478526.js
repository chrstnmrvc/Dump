(function(window, undefined) {

  var jimLinks = {
    "e746042c-5631-4455-a5a1-803d4dd10030" : {
      "Button_1" : [
        "d12245cc-1680-458d-89dd-4f0d7fb22724"
      ],
      "Button_2" : [
        "e746042c-5631-4455-a5a1-803d4dd10030"
      ],
      "Button_3" : [
        "1d08b623-ad84-45c1-933a-cca98249fc81"
      ],
      "Button_4" : [
        "d95a20ca-2770-41ad-bd0c-419dd9037510"
      ],
      "Button_5" : [
        "c9e9c56b-b4cb-4115-8654-67f5e08f41ef"
      ],
      "Image_1" : [
        "d12245cc-1680-458d-89dd-4f0d7fb22724"
      ]
    },
    "c9e9c56b-b4cb-4115-8654-67f5e08f41ef" : {
      "Button_2" : [
        "d12245cc-1680-458d-89dd-4f0d7fb22724"
      ],
      "Button_3" : [
        "e746042c-5631-4455-a5a1-803d4dd10030"
      ],
      "Button_4" : [
        "1d08b623-ad84-45c1-933a-cca98249fc81"
      ],
      "Button_5" : [
        "d95a20ca-2770-41ad-bd0c-419dd9037510"
      ],
      "Button_6" : [
        "c9e9c56b-b4cb-4115-8654-67f5e08f41ef"
      ],
      "Image_1" : [
        "d12245cc-1680-458d-89dd-4f0d7fb22724"
      ]
    },
    "1d08b623-ad84-45c1-933a-cca98249fc81" : {
      "Button_1" : [
        "d12245cc-1680-458d-89dd-4f0d7fb22724"
      ],
      "Button_2" : [
        "e746042c-5631-4455-a5a1-803d4dd10030"
      ],
      "Button_3" : [
        "1d08b623-ad84-45c1-933a-cca98249fc81"
      ],
      "Button_4" : [
        "d95a20ca-2770-41ad-bd0c-419dd9037510"
      ],
      "Button_5" : [
        "c9e9c56b-b4cb-4115-8654-67f5e08f41ef"
      ],
      "Image_1" : [
        "d12245cc-1680-458d-89dd-4f0d7fb22724"
      ],
      "Button_6" : [
        "d12245cc-1680-458d-89dd-4f0d7fb22724"
      ],
      "Button_7" : [
        "e746042c-5631-4455-a5a1-803d4dd10030"
      ],
      "Button_8" : [
        "1d08b623-ad84-45c1-933a-cca98249fc81"
      ],
      "Button_9" : [
        "d95a20ca-2770-41ad-bd0c-419dd9037510"
      ],
      "Button_10" : [
        "c9e9c56b-b4cb-4115-8654-67f5e08f41ef"
      ],
      "Image_2" : [
        "d12245cc-1680-458d-89dd-4f0d7fb22724"
      ]
    },
    "d95a20ca-2770-41ad-bd0c-419dd9037510" : {
      "Button_1" : [
        "d12245cc-1680-458d-89dd-4f0d7fb22724"
      ],
      "Button_2" : [
        "e746042c-5631-4455-a5a1-803d4dd10030"
      ],
      "Button_3" : [
        "1d08b623-ad84-45c1-933a-cca98249fc81"
      ],
      "Button_4" : [
        "d95a20ca-2770-41ad-bd0c-419dd9037510"
      ],
      "Button_5" : [
        "c9e9c56b-b4cb-4115-8654-67f5e08f41ef"
      ],
      "Image_1" : [
        "d12245cc-1680-458d-89dd-4f0d7fb22724"
      ]
    },
    "d12245cc-1680-458d-89dd-4f0d7fb22724" : {
      "Button_6" : [
        "d12245cc-1680-458d-89dd-4f0d7fb22724"
      ],
      "Button_7" : [
        "e746042c-5631-4455-a5a1-803d4dd10030"
      ],
      "Button_8" : [
        "1d08b623-ad84-45c1-933a-cca98249fc81"
      ],
      "Button_10" : [
        "d95a20ca-2770-41ad-bd0c-419dd9037510"
      ],
      "Button_11" : [
        "c9e9c56b-b4cb-4115-8654-67f5e08f41ef"
      ],
      "Image_1" : [
        "d12245cc-1680-458d-89dd-4f0d7fb22724"
      ]
    }    
  }

  window.jimLinks = jimLinks;
})(window);
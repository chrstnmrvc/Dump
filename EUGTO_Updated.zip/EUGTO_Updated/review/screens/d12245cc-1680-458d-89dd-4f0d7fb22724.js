var content='<div class="ui-page" deviceName="web" deviceType="desktop" deviceWidth="1366" deviceHeight="1297">\
    <div id="t-f39803f7-df02-4169-93eb-7547fb8c961a" class="template growth-both devWeb canvas firer commentable non-processed" alignment="left" name="Template 1" width="1366" height="768">\
    <div id="backgroundBox"><div class="colorLayer"></div><div class="imageLayer"></div></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./resources/templates/f39803f7-df02-4169-93eb-7547fb8c961a-1667870478526.css" />\
      <div class="freeLayout">\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>\
    <div id="s-d12245cc-1680-458d-89dd-4f0d7fb22724" class="screen growth-vertical devWeb canvas PORTRAIT firer commentable non-processed" alignment="left" name="Screen 1 - Eugto" width="1366" height="1297">\
    <div id="backgroundBox"><div class="colorLayer"></div><div class="imageLayer"></div></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./resources/screens/d12245cc-1680-458d-89dd-4f0d7fb22724-1667870478526.css" />\
      <div class="freeLayout">\
      <div id="s-Rectangle_4" class="rectangle manualfit firer commentable non-processed" customid="Rectangle 2"   datasizewidth="396.8px" datasizeheight="140.7px" datasizewidthpx="396.84273557944744" datasizeheightpx="140.69229507100727" dataX="922.2" dataY="964.8" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Rectangle_4_0"></span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Rectangle_3" class="rectangle manualfit firer commentable non-processed" customid="Rectangle 2"   datasizewidth="396.8px" datasizeheight="60.1px" datasizewidthpx="396.84273557944744" datasizeheightpx="60.13101577413238" dataX="922.2" dataY="908.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Rectangle_3_0"></span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Category_2" class="dropdown firer commentable non-processed" customid="Category 2"    datasizewidth="296.0px" datasizeheight="39.0px" dataX="299.0" dataY="177.0"  tabindex="-1"><div class="backgroundLayer">\
        <div class="colorLayer"></div>\
        <div class="imageLayer"></div>\
      </div><div class="borderLayer"><div class="paddingLayer"><div class="content icon"><div class="valign"><div class="value">Primary School</div></div></div></div></div><select id="s-Category_2-options" class="s-d12245cc-1680-458d-89dd-4f0d7fb22724 dropdown-options" ><option  class="option">Small Office</option>\
      <option  class="option">Medium Office</option>\
      <option  class="option">Large Office</option>\
      <option selected="selected" class="option">Primary School</option>\
      <option  class="option">Secondary School</option>\
      <option  class="option">University</option>\
      <option  class="option">Hospital</option>\
      <option  class="option">Mall</option></select></div>\
\
      <div id="s-Group_2" class="group firer ie-background commentable non-processed" customid="Search input" datasizewidth="0.0px" datasizeheight="0.0px" >\
        <div id="s-Input_15" class="text firer commentable non-processed" customid="Input"  datasizewidth="365.0px" datasizeheight="41.0px" dataX="241.0" dataY="128.0" ><div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div><div class="borderLayer"><div class="paddingLayer"><div class="content"><div class="valign"><input type="text"  value="" maxlength="100"  tabindex="-1" placeholder="Search"/></div></div>  </div></div></div>\
        <div id="s-Path_1" class="path firer commentable non-processed" customid="search icon"   datasizewidth="20.3px" datasizeheight="20.7px" dataX="573.0" dataY="137.7"  >\
          <div class="borderLayer">\
          	<div class="imageViewport">\
            	<?xml version="1.0" encoding="UTF-8"?>\
            	<svg xmlns="http://www.w3.org/2000/svg" width="20.341541290283203" height="20.679365158081055" viewBox="573.0 137.66031746031769 20.341541290283203 20.679365158081055" preserveAspectRatio="none">\
            	  <g>\
            	    <defs>\
            	      <path id="s-Path_1-d1224" d="M586.8525895168468 146.1181776781332 C586.8525895168468 149.22008285522492 584.370921694082 151.74296418256162 581.3196901451513 151.74296418256162 C578.2684591067261 151.74296418256162 575.7664496858478 149.22008285522492 575.7664496858478 146.1181776781332 C575.7664496858478 142.99559411580327 578.2481175086127 140.4727107125319 581.3196901451513 140.4727107125319 C584.370921694082 140.4727107125319 586.8525895168468 143.01627250104147 586.8525895168468 146.1181776781332 L586.8525895168468 146.1181776781332 Z M588.1747893101777 150.89511094503666 C589.1308423794881 149.50959270416774 589.6393802903026 147.81388622911783 589.6393802903026 146.1181776781332 C589.6393802903026 141.44464152725743 585.9168780456499 137.66031746031769 581.3196901451513 137.66031746031769 C576.7225019894 137.66031746031769 573.0 141.44464152725743 573.0 146.1181776781332 C573.0 150.79171486697632 576.7225019894 154.5760378959487 581.3196901451513 154.5760378959487 C582.9876971064108 154.5760378959487 584.6557030466594 154.03837496853944 586.0389276343305 153.08712357701947 L591.2056782399841 158.3396825396829 L593.341540936842 156.1683482929383 L588.1747893101777 150.89511094503666 Z "></path>\
            	    </defs>\
            	    <g style="mix-blend-mode:normal">\
            	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_1-d1224" fill="#392E2E" fill-opacity="1.0"></use>\
            	    </g>\
            	  </g>\
            	</svg>\
\
            </div>\
          </div>\
        </div>\
      </div>\
\
      <div id="s-Rectangle_6" class="rectangle manualfit firer ie-background commentable non-processed" customid="Rectangle 3"   datasizewidth="254.7px" datasizeheight="43.0px" datasizewidthpx="254.69791676919115" datasizeheightpx="43.0" dataX="39.0" dataY="175.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Rectangle_6_0">Select your building type here:</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Rectangle_7" class="rectangle manualfit firer ie-background commentable non-processed" customid="Rectangle 7"   datasizewidth="198.0px" datasizeheight="35.0px" datasizewidthpx="198.0" datasizeheightpx="35.00000000000003" dataX="39.0" dataY="126.5" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Rectangle_7_0">Search your area here:</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Path_2" class="path firer ie-background commentable non-processed" customid="Path 2"   datasizewidth="1303.7px" datasizeheight="3.0px" dataX="-1.0" dataY="1199.5"  >\
        <div class="borderLayer">\
        	<div class="imageViewport">\
          	<?xml version="1.0" encoding="UTF-8"?>\
          	<svg xmlns="http://www.w3.org/2000/svg" width="1303.747314453125" height="2.0" viewBox="-0.999999142416705 1199.475948262598 1303.747314453125 2.0" preserveAspectRatio="none">\
          	  <g>\
          	    <defs>\
          	      <path id="s-Path_2-d1224" d="M-2.4158453015843406E-13 1200.475948262598 L1301.7473629417052 1200.475948262598 "></path>\
          	    </defs>\
          	    <g style="mix-blend-mode:normal">\
          	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_2-d1224" fill="none" stroke-width="1.0" stroke="#1D4855" stroke-linecap="square"></use>\
          	    </g>\
          	  </g>\
          	</svg>\
\
          </div>\
        </div>\
      </div>\
      <div id="s-Button_6" class="button multiline manualfit firer mouseenter mouseleave click commentable non-processed" customid="Secondary button"   datasizewidth="116.0px" datasizeheight="64.0px" dataX="770.1" dataY="46.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Button_6_0">Map</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Button_7" class="button multiline manualfit firer mouseenter mouseleave click commentable non-processed" customid="Secondary button"   datasizewidth="109.5px" datasizeheight="64.0px" dataX="886.1" dataY="46.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Button_7_0">About</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Button_8" class="button multiline manualfit firer mouseenter mouseleave click commentable non-processed" customid="Secondary button"   datasizewidth="114.0px" datasizeheight="64.0px" dataX="995.6" dataY="46.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Button_8_0">Help</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Button_10" class="button multiline manualfit firer mouseenter mouseleave click commentable non-processed" customid="Secondary button"   datasizewidth="111.0px" datasizeheight="64.0px" dataX="1109.6" dataY="46.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Button_10_0">Team</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Button_11" class="button multiline manualfit firer mouseenter mouseleave click commentable non-processed" customid="Secondary button"   datasizewidth="114.5px" datasizeheight="64.0px" dataX="1220.0" dataY="46.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Button_11_0">Contact</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Rectangle_9" class="rectangle manualfit firer ie-background commentable non-processed" customid="Rectangle 9"   datasizewidth="198.0px" datasizeheight="32.0px" datasizewidthpx="197.99999999999977" datasizeheightpx="32.0" dataX="566.7" dataY="1232.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Rectangle_9_0">&copy; 2022 EUGTO</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
\
      <div id="s-Image_1" class="image firer click ie-background commentable non-processed" customid="eugto logo 2"   datasizewidth="216.6px" datasizeheight="158.6px" dataX="-26.0" dataY="-14.6"   alt="image">\
        <div class="borderLayer">\
        	<div class="imageViewport">\
        		<img src="./images/d8ee76cf-76a7-4b43-a236-b152825d306e.png" />\
        	</div>\
        </div>\
      </div>\
\
      <div id="s-Paragraph_1" class="richtext manualfit firer ie-background commentable non-processed" customid="EUGTO (U-28)"   datasizewidth="427.8px" datasizeheight="93.0px" dataX="159.0" dataY="17.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Paragraph_1_0">EUGTO (U-28)</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
\
      <div id="s-Image_2" class="image firer click ie-background commentable non-processed" customid="Image 2"   datasizewidth="112.8px" datasizeheight="109.8px" dataX="1023.3" dataY="644.4"   alt="image">\
        <div class="borderLayer">\
        	<div class="imageViewport">\
        		<img src="./images/c0dd3f14-2be5-4c49-895d-e82cf85a45fe.png" />\
        	</div>\
        </div>\
      </div>\
\
\
      <div id="s-Image_3" class="image firer ie-background commentable non-processed" customid="Image 3"   datasizewidth="114.8px" datasizeheight="108.8px" dataX="1162.6" dataY="644.9"   alt="image">\
        <div class="borderLayer">\
        	<div class="imageViewport">\
        		<img src="./images/58f5d7fd-c107-40b9-881b-9c0f0e75c339.png" />\
        	</div>\
        </div>\
      </div>\
\
\
      <div id="s-Image_4" class="image firer click ie-background commentable non-processed" customid="Image 4"   datasizewidth="115.5px" datasizeheight="109.9px" dataX="1021.9" dataY="778.0"   alt="image">\
        <div class="borderLayer">\
        	<div class="imageViewport">\
        		<img src="./images/cb07f12b-9851-4bd3-ab30-8379163bfb3f.png" />\
        	</div>\
        </div>\
      </div>\
\
\
      <div id="s-Image_5" class="image firer click ie-background commentable non-processed" customid="Image 5"   datasizewidth="116.0px" datasizeheight="107.7px" dataX="1162.0" dataY="779.1"   alt="image">\
        <div class="borderLayer">\
        	<div class="imageViewport">\
        		<img src="./images/c759b685-246a-4633-a08d-76b1f1bb2dc3.png" />\
        	</div>\
        </div>\
      </div>\
\
      <div id="s-Paragraph_4" class="richtext manualfit firer ie-background commentable non-processed" customid="ENVIRONMENTAL IMPACTS"   datasizewidth="365.5px" datasizeheight="44.0px" dataX="969.0" dataY="582.6" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Paragraph_4_0">ENVIRONMENTAL IMPACTS</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Paragraph_6" class="richtext manualfit firer ie-background commentable non-processed" customid="SHARE FULL REPORT:"   datasizewidth="396.8px" datasizeheight="36.0px" dataX="922.2" dataY="920.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Paragraph_6_0">SHARE FULL REPORT:</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
\
      <div id="s-Image_6" class="image firer click ie-background commentable non-processed" customid="Image 6"   datasizewidth="83.1px" datasizeheight="79.0px" dataX="1006.1" dataY="977.5"   alt="image">\
        <div class="borderLayer">\
        	<div class="imageViewport">\
        		<img src="./images/b4528bc2-03d8-42d3-9814-cc012a2d38b3.png" />\
        	</div>\
        </div>\
      </div>\
\
\
      <div id="s-Image_7" class="image firer click ie-background commentable non-processed" customid="Image 7"   datasizewidth="71.0px" datasizeheight="65.5px" dataX="1158.1" dataY="984.2"   alt="image">\
        <div class="borderLayer">\
        	<div class="imageViewport">\
        		<img src="./images/b367c2b7-8900-401b-8cc2-4b86a5cea764.png" />\
        	</div>\
        </div>\
      </div>\
\
      <div id="s-Paragraph_9" class="richtext autofit firer ie-background commentable non-processed" customid="ESTABLISHING URBAN BUILDI"   datasizewidth="427.8px" datasizeheight="34.0px" dataX="159.0" dataY="75.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Paragraph_9_0">ESTABLISHING</span><span id="rtr-s-Paragraph_9_1"> </span><span id="rtr-s-Paragraph_9_2">URBAN BUILDING PLACEMENTS</span><span id="rtr-s-Paragraph_9_3"> </span><span id="rtr-s-Paragraph_9_4">AND GENERATING <br /></span><span id="rtr-s-Paragraph_9_5">ENVIRONMENTAL IMPACTS </span><span id="rtr-s-Paragraph_9_6">THROUGH </span><span id="rtr-s-Paragraph_9_7">ARTIFICIAL INTELLIGENCE</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Paragraph_11" class="richtext manualfit firer ie-background commentable non-processed" customid="DOWNLOAD FILE"   datasizewidth="181.7px" datasizeheight="36.0px" dataX="956.8" dataY="1069.2" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Paragraph_11_0">DOWNLOAD FILE</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Paragraph_12" class="richtext manualfit firer ie-background commentable non-processed" customid="EMAIL-SHARING"   datasizewidth="181.7px" datasizeheight="36.0px" dataX="1102.8" dataY="1069.2" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Paragraph_12_0">EMAIL-SHARING</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
\
      <div id="s-Image_9" class="image firer click ie-background commentable non-processed" customid="Image 3"   datasizewidth="114.8px" datasizeheight="108.8px" dataX="1162.6" dataY="644.9"   alt="image">\
        <div class="borderLayer">\
        	<div class="imageViewport">\
        		<img src="./images/58f5d7fd-c107-40b9-881b-9c0f0e75c339.png" />\
        	</div>\
        </div>\
      </div>\
\
\
      <div id="s-Group_1" class="group firer ie-background commentable non-processed" customid="Group 1" datasizewidth="0.0px" datasizeheight="0.0px" >\
        <div id="s-Paragraph_7" class="richtext manualfit firer ie-background commentable non-processed" customid="How are we doing?"   datasizewidth="147.3px" datasizeheight="17.0px" dataX="980.0" dataY="1139.8" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Paragraph_7_0">How are we doing? </span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Rectangle_5" class="rectangle manualfit firer commentable non-processed" customid="Rectangle 9"   datasizewidth="146.0px" datasizeheight="32.0px" datasizewidthpx="145.967785252589" datasizeheightpx="32.00000000000023" dataX="1127.3" dataY="1132.3" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Rectangle_5_0">FEEDBACK</span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
\
\
      <div id="s-Group_6" class="group firer ie-background commentable non-processed" customid="Group 6" datasizewidth="0.0px" datasizeheight="0.0px" >\
        <div id="s-Path_6" class="path firer commentable non-processed" customid="Twitter icon"   datasizewidth="19.7px" datasizeheight="16.0px" dataX="1063.2" dataY="1241.0"  >\
          <div class="borderLayer">\
          	<div class="imageViewport">\
            	<?xml version="1.0" encoding="UTF-8"?>\
            	<svg xmlns="http://www.w3.org/2000/svg" width="19.69230842590332" height="16.0" viewBox="1063.1750117631664 1241.042671196702 19.69230842590332 16.0" preserveAspectRatio="none">\
            	  <g>\
            	    <defs>\
            	      <path id="s-Path_6-d1224" d="M1082.8673196191223 1242.888824977961 C1082.128858047931 1243.2580557635565 1081.3903964767399 1243.3811326798618 1080.5288580992828 1243.5042095961671 C1081.3903965500995 1243.0119018942662 1082.005781241665 1242.1503634067697 1082.251935000916 1241.2888250293126 C1081.513473429725 1241.7811327312133 1080.6519350522678 1242.1503634801293 1079.6673197218256 1242.2734404331143 C1078.9288581506346 1241.534978861923 1077.8211658672074 1241.042671196702 1076.7134734370609 1241.042671196702 C1074.6211659699106 1241.0426711233424 1072.7750121152922 1242.888824977961 1072.7750121152922 1245.1042095448154 C1072.7750121152922 1245.473440330411 1072.7750121152922 1245.7195941630214 1072.8980890407674 1245.965747995632 C1069.5750116311192 1245.8426712627256 1066.4980888335267 1244.2426710206391 1064.5288580259232 1241.7811326945337 C1064.1596272403276 1242.39651731274 1064.0365502873426 1243.134978883931 1064.0365502873426 1243.8734403084031 C1064.0365502873426 1245.2272864978004 1064.7750118585338 1246.4580555874936 1065.882704141961 1247.1965173054039 C1065.1442426441295 1247.1965173054039 1064.5288580259232 1246.950363692872 1063.9134734077172 1246.7042094934636 C1063.9134734077172 1246.7042094934636 1063.9134734077172 1246.7042094934636 1063.9134734077172 1246.7042094934636 C1063.9134734077172 1248.673440301067 1065.2673195971145 1250.2734403964346 1067.1134733050137 1250.6426711086706 C1066.8673195457627 1250.7657482083748 1066.4980888335267 1250.8888250146406 1066.1288581212907 1250.8888250146406 C1065.8827042153205 1250.8888250146406 1065.6365503093505 1250.7657482083748 1065.3903964033805 1250.7657482083748 C1065.8827041052812 1252.365748157023 1067.359627210984 1253.5965173934353 1069.2057809188832 1253.5965173934353 C1067.8519347294857 1254.7042096768625 1066.1288578278525 1255.3195942950688 1064.159627166968 1255.3195942950688 C1063.7903963813726 1255.3195942950688 1063.544242548762 1255.3195942950688 1063.1750117631664 1255.3195942950688 C1064.8980887381592 1256.4272865784958 1067.113473451733 1257.042671196702 1069.3288580185872 1257.042671196702 C1076.7134734370609 1257.042671196702 1080.775012151972 1250.8888250146406 1080.775012151972 1245.4734408439278 C1080.775012151972 1245.3503639184526 1080.775012151972 1245.1042100583322 1080.775012151972 1244.981133142027 C1081.63655038271 1244.4888249266091 1082.3750123940586 1243.7503635021371 1082.8673196191223 1242.888824977961 Z "></path>\
            	    </defs>\
            	    <g style="mix-blend-mode:normal">\
            	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_6-d1224" fill="#000000" fill-opacity="1.0"></use>\
            	    </g>\
            	  </g>\
            	</svg>\
\
            </div>\
          </div>\
        </div>\
        <div id="s-Path_7" class="path firer commentable non-processed" customid="Youtube"   datasizewidth="24.2px" datasizeheight="16.9px" dataX="1100.2" dataY="1240.6"  >\
          <div class="borderLayer">\
          	<div class="imageViewport">\
            	<?xml version="1.0" encoding="UTF-8"?>\
            	<svg xmlns="http://www.w3.org/2000/svg" width="24.200000762939453" height="16.936668395996094" viewBox="1100.1750117631664 1240.5743368725598 24.200000762939453 16.936668395996094" preserveAspectRatio="none">\
            	  <g>\
            	    <defs>\
            	      <path id="s-Path_7-d1224" d="M1123.8731876630454 1243.223004924938 C1123.5935146376632 1242.1865695932731 1122.7791726081648 1241.3722276029978 1121.7427373549458 1241.0925546168385 C1119.8426059397086 1240.5743368725598 1112.274983112219 1240.5743368725598 1112.274983112219 1240.5743368725598 C1112.274983112219 1240.5743368725598 1104.6991341056873 1240.5743368725598 1102.807228398815 1241.0761031608856 C1101.7872444838797 1241.347550477903 1100.9482253685096 1242.1865695932731 1100.6767780514922 1243.223004924938 C1100.1750117631664 1245.1149106318105 1100.1750117631664 1249.0467841685538 1100.1750117631664 1249.0467841685538 C1100.1750117631664 1249.0467841685538 1100.1750117631664 1252.9951091220266 1100.6767780514922 1254.8623375469122 C1100.9564510768746 1255.8987728785771 1101.770793106373 1256.7131148688525 1102.8072283595918 1256.9927878550118 C1104.7238110346666 1257.5110055208443 1112.2749824454265 1257.5110055208443 1112.2749824454265 1257.5110055208443 C1112.2749824454265 1257.5110055208443 1119.8508308243886 1257.5110055208443 1121.742736531261 1257.0092392325184 C1122.7791718629262 1256.729566207136 1123.5935138532016 1255.9152241776378 1123.8731868393606 1254.8787889244188 C1124.3749531276867 1252.9868832175464 1124.3749531276867 1249.0632355460605 1124.3749531276867 1249.0632355460605 C1124.3749531276867 1249.0632355460605 1124.3914043090779 1245.1149106318105 1123.8731876630454 1243.223004924938 Z M1109.8566333251335 1252.6743082216124 L1109.8566333251335 1245.4192607430643 L1116.1575017712034 1249.0467841685538 L1109.8566333251335 1252.6743082216124 Z "></path>\
            	    </defs>\
            	    <g style="mix-blend-mode:normal">\
            	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_7-d1224" fill="#000000" fill-opacity="1.0"></use>\
            	    </g>\
            	  </g>\
            	</svg>\
\
            </div>\
          </div>\
        </div>\
        <div id="s-Path_15" class="path firer commentable non-processed" customid="Mail icon"   datasizewidth="22.8px" datasizeheight="16.2px" dataX="1218.2" dataY="1240.3"  >\
          <div class="borderLayer">\
          	<div class="imageViewport">\
            	<?xml version="1.0" encoding="UTF-8"?>\
            	<svg xmlns="http://www.w3.org/2000/svg" width="22.821897506713867" height="16.200000762939453" viewBox="1218.1750117631664 1240.2620315482645 22.821897506713867 16.200000762939453" preserveAspectRatio="none">\
            	  <g>\
            	    <defs>\
            	      <path id="s-Path_15-d1224" d="M1238.6910694281617 1240.2620315482645 L1220.4808510934809 1240.2620315482645 C1219.2096832744057 1240.2620315482645 1218.1750117631664 1241.3213380954858 1218.1750117631664 1242.6269950025257 L1218.1750117631664 1254.0872140420204 C1218.1750117631664 1255.3977979750518 1219.2096832744057 1256.4620315482646 1220.4808510934809 1256.4620315482646 L1238.691069992013 1256.4620315482646 C1239.9622378110882 1256.4620315482646 1240.9969093223274 1255.3977979750518 1240.9969093223274 1254.0872140420204 L1240.9969093223274 1242.6269950025257 C1240.9969096982284 1241.3213380954858 1239.962238186989 1240.2620315482645 1238.6910694281617 1240.2620315482645 Z M1233.6507416677089 1248.4507173582836 L1239.696178595502 1242.7107541624544 L1239.696178595502 1254.0872134781694 C1239.696178595502 1254.2103886580787 1239.676470566423 1254.3286368354904 1239.6370545067962 1254.4468850129024 L1233.6507416677089 1248.4507173582836 Z M1225.5408875217508 1248.460571222316 L1219.5348657681616 1254.4567395817487 C1219.4954497100032 1254.338491404337 1219.4757416794557 1254.2153162244276 1219.4757416794557 1254.0872140420204 L1219.4757416794557 1242.7107541624544 L1225.5408875217508 1248.460571222316 Z M1230.1969093223274 1249.9386733812294 C1229.8323107850968 1250.2884908874732 1229.3543910729518 1250.2884908874732 1228.989792559215 1249.9386733812294 L1228.989792559215 1249.9386733812294 L1220.2049387656639 1241.612031501277 C1220.3034789095916 1241.582469456924 1220.392165036777 1241.5627614293132 1220.4808511639624 1241.5627614293132 L1238.6910700624942 1241.5627614293132 C1238.7797561896798 1241.5627614293132 1238.8733693311096 1241.5775424514895 1238.9669824607927 1241.612031501277 L1230.1969093223274 1249.9386733812294 Z M1226.4819461969796 1249.3622136896136 L1228.093077587785 1250.8846588944991 C1228.9355958371607 1251.6828340979023 1230.2511067022083 1251.6828340979023 1231.093625045559 1250.8846588944991 L1232.7047564363647 1249.357286663622 L1238.5038437561407 1255.1662282233312 L1220.677931381336 1255.1662282233312 L1226.4819461969796 1249.3622136896136 Z "></path>\
            	    </defs>\
            	    <g style="mix-blend-mode:normal">\
            	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_15-d1224" fill="#000000" fill-opacity="1.0"></use>\
            	    </g>\
            	  </g>\
            	</svg>\
\
            </div>\
          </div>\
        </div>\
        <div id="s-Paragraph_10" class="richtext manualfit firer ie-background commentable non-processed" customid="Stay connected to us!"   datasizewidth="383.0px" datasizeheight="21.0px" dataX="933.1" dataY="1215.3" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Paragraph_10_0">Stay connected to us!</span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Path_8" class="path firer commentable non-processed" customid="Path"   datasizewidth="18.9px" datasizeheight="18.9px" dataX="1143.0" dataY="1239.0"  >\
          <div class="borderLayer">\
          	<div class="imageViewport">\
            	<?xml version="1.0" encoding="UTF-8"?>\
            	<svg xmlns="http://www.w3.org/2000/svg" width="18.90377426147461" height="18.900022506713867" viewBox="1143.0 1239.0 18.90377426147461 18.900022506713867" preserveAspectRatio="none">\
            	  <g>\
            	    <defs>\
            	      <path id="s-Path_8-d1224" d="M1152.4481361458193 1240.7028400390243 C1154.972390242103 1240.7028400390243 1155.268699173003 1240.7140922860472 1156.266398598311 1240.7591012719029 C1157.189082831828 1240.8003595102414 1157.6879324729423 1240.9541402053947 1158.0217490355076 1241.0854164154448 C1158.464337407973 1241.2579508593622 1158.7794003335553 1241.4604913013022 1159.1094662044939 1241.7905571722408 C1159.4395321112022 1242.1206230789492 1159.645823298424 1242.4356860045314 1159.8146069612897 1242.878274341227 C1159.9421324260582 1243.212090975332 1160.0996638709644 1243.7109406164464 1160.1409221048316 1244.6336247784236 C1160.185931092923 1245.6313239891122 1160.1971833377102 1245.9276331346314 1160.1971833377102 1248.4518872309152 C1160.1971833377102 1250.976141327199 1160.1859310906873 1251.2724502580988 1160.1409221048316 1252.270149683407 C1160.099663866493 1253.192833916924 1159.9458831713398 1253.6916835580382 1159.8146069612897 1254.0255001206035 C1159.6420725173723 1254.4680884930692 1159.4395320754325 1254.7831514186512 1159.1094662044939 1255.1132172895898 C1158.7794002977853 1255.4432831962984 1158.4643373722033 1255.6495743835198 1158.0217490355076 1255.8183580463856 C1157.6879324014023 1255.945883511154 1157.189082760288 1256.1034149560603 1156.266398598311 1256.1446731899275 C1155.2686993876225 1256.189682178019 1154.972390242103 1256.200934422806 1152.4481361458193 1256.200934422806 C1149.9238820495355 1256.200934422806 1149.6275731186358 1256.1896821757834 1148.6298736933277 1256.1446731899275 C1147.7071894598105 1256.103414951589 1147.2083398186965 1255.9496342564357 1146.8745232561312 1255.8183580463856 C1146.4319348836655 1255.6458236024682 1146.1168719580833 1255.4432831605284 1145.786806087145 1255.1132172895898 C1145.4567401804363 1254.7831513828812 1145.2504489932148 1254.4680884572992 1145.0816653303489 1254.0255001206035 C1144.9541398655804 1253.6916834864983 1144.7966084206744 1253.1928338453843 1144.755350186807 1252.270149683407 C1144.7103411987157 1251.2724504727184 1144.6990889539284 1250.976141327199 1144.6990889539284 1248.4518872309152 C1144.6990889539284 1245.9276331346314 1144.7103412009512 1245.6313242037318 1144.755350186807 1244.6336247784236 C1144.7966084251455 1243.7109405449064 1144.9503891202987 1243.2120909037924 1145.0816653303489 1242.878274341227 C1145.2541997742662 1242.4356859687614 1145.4567402162063 1242.1206230431792 1145.786806087145 1241.7905571722408 C1146.1168719938532 1241.4604912655323 1146.4319349194354 1241.2542000783108 1146.8745232561312 1241.0854164154448 C1147.2083398902362 1240.9578909506763 1147.7071895313504 1240.8003595057703 1148.6298736933277 1240.7591012719029 C1149.6275731186358 1240.7103414222777 1149.9276330273217 1240.7028400390243 1152.4481361458193 1240.7028400390243 M1152.4481361458193 1239.0 C1149.8826238693232 1239.0 1149.5600595247176 1239.0112522470229 1148.5511080245294 1239.0562612328786 C1147.5459075021274 1239.10127022097 1146.859520632704 1239.2625524201 1146.2594008153324 1239.4950988421776 C1145.6367764905012 1239.7351467727035 1145.1116716503009 1240.0614619341304 1144.5865668816405 1240.5865667743305 C1144.06146204144 1241.111671614531 1143.7388976252948 1241.6405272178977 1143.4950989494876 1242.2594007080227 C1143.26255252741 1242.8595205253944 1143.1012703193373 1243.5459075378974 1143.0562613401885 1244.5548590380856 C1143.0112522470229 1245.5600595247176 1143.0 1245.8826241554825 1143.0 1248.4481361458193 C1143.0 1251.0136484223156 1143.0112522470229 1251.336212766921 1143.0562612328786 1252.345164267109 C1143.10127022097 1253.350364932591 1143.2625524201 1254.036751945094 1143.4950988421776 1254.640622597172 C1143.7351467727035 1255.2632469220034 1144.0614619341304 1255.7883517622038 1144.5865667743305 1256.3134565308642 C1145.111671614531 1256.8385613710643 1145.6405272178977 1257.1611257872098 1146.2594007080224 1257.404924463017 C1146.8595205253944 1257.6374708850947 1147.5459075378974 1257.7987530931673 1148.5548590380856 1257.8437620723162 C1149.563810466734 1257.8887710604074 1149.8826241912525 1257.9000233051947 1152.4518871593755 1257.9000233051947 C1155.0211501274982 1257.9000233051947 1155.339963780477 1257.8887710581719 1156.348915280665 1257.8437620723162 C1157.354115946147 1257.7987530842247 1158.04050295865 1257.6374708850947 1158.6443736107283 1257.404924463017 C1159.2669979355594 1257.1648765324912 1159.7921027757598 1256.8385613710643 1160.3172075444202 1256.3134565308642 C1160.8423123846203 1255.7883516906638 1161.1648768007658 1255.259496087297 1161.408675476573 1254.640622597172 C1161.6412218986507 1254.0405027798004 1161.8025041067233 1253.3541157672973 1161.8475130858722 1252.345164267109 C1161.8925220739634 1251.3362128384608 1161.9037743187507 1251.0173991139422 1161.9037743187507 1248.4481361458193 C1161.9037743187507 1245.8788731776965 1161.8925220717279 1245.5600595247176 1161.8475130858722 1244.5511080245294 C1161.8025040977807 1243.5459073590478 1161.6412218986507 1242.8595203465447 1161.408675476573 1242.2556496944665 C1161.1686275460472 1241.6330253696353 1160.8423123846203 1241.107920529435 1160.3172075444202 1240.5828157607746 C1159.7921027042198 1240.0577109205742 1159.263247100853 1239.735146504429 1158.6443736107283 1239.4913478286217 C1158.0442537933563 1239.258801406544 1157.3578667808533 1239.0975191984714 1156.348915280665 1239.0525102193226 C1155.3362127669209 1239.0112522470229 1155.013648136156 1239.0 1152.4481361458193 1239.0 L1152.4481361458193 1239.0 Z "></path>\
            	    </defs>\
            	    <g style="mix-blend-mode:normal">\
            	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_8-d1224" fill="#000000" fill-opacity="1.0"></use>\
            	    </g>\
            	  </g>\
            	</svg>\
\
            </div>\
          </div>\
        </div>\
        <div id="s-Path_9" class="path firer commentable non-processed" customid="Path"   datasizewidth="9.7px" datasizeheight="9.7px" dataX="1147.6" dataY="1243.6"  >\
          <div class="borderLayer">\
          	<div class="imageViewport">\
            	<?xml version="1.0" encoding="UTF-8"?>\
            	<svg xmlns="http://www.w3.org/2000/svg" width="9.706939697265625" height="9.706932067871094" viewBox="1147.5984183653086 1243.5965428585307 9.706939697265625 9.706932067871094" preserveAspectRatio="none">\
            	  <g>\
            	    <defs>\
            	      <path id="s-Path_9-d1224" d="M1152.4518871593752 1243.5965428585307 C1149.7738524171218 1243.5965428585307 1147.5984183653086 1245.7682265048768 1147.5984183653086 1248.4500116525974 C1147.5984183653086 1251.1317968003182 1149.7701020116547 1253.303480446664 1152.4518871593752 1253.303480446664 C1155.133672307096 1253.303480446664 1157.305355953442 1251.1317968003182 1157.305355953442 1248.4500116525974 C1157.305355953442 1245.7682265048768 1155.1336725932554 1243.5965428585307 1152.4518871593752 1243.5965428585307 Z M1152.4518871593752 1251.5968900021726 C1150.7115396317652 1251.5968900021726 1149.3012581181736 1250.1866084885808 1149.3012581181736 1248.4462609609707 C1149.3012581181736 1246.7059134333606 1150.7115396317652 1245.295631919769 1152.4518871593752 1245.295631919769 C1154.1922346869853 1245.295631919769 1155.6025162005772 1246.7059134333606 1155.6025162005772 1248.4462609609707 C1155.6025162005772 1250.1866082024212 1154.192234400826 1251.5968900021726 1152.4518871593752 1251.5968900021726 Z "></path>\
            	    </defs>\
            	    <g style="mix-blend-mode:normal">\
            	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_9-d1224" fill="#000000" fill-opacity="1.0"></use>\
            	    </g>\
            	  </g>\
            	</svg>\
\
            </div>\
          </div>\
        </div>\
        <div id="s-Path_10" class="path firer commentable non-processed" customid="Circle"   datasizewidth="2.3px" datasizeheight="2.3px" dataX="1156.0" dataY="1242.0"  >\
          <div class="borderLayer">\
          	<div class="imageViewport">\
            	<?xml version="1.0" encoding="UTF-8"?>\
            	<svg xmlns="http://www.w3.org/2000/svg" width="2.2655029296875" height="2.275604248046875" viewBox="1155.9999853046413 1242.0000038670964 2.2655029296875 2.275604248046875" preserveAspectRatio="none">\
            	  <g>\
            	    <defs>\
            	      <path id="s-Path_10-d1224" d="M1156.0000113244305 1243.1378032264474 C1155.9972323536635 1243.7591984271937 1156.5062765894309 1244.272816157744 1157.1276717901774 1244.275595128511 C1157.7528983425311 1244.278391233646 1158.2682597973758 1243.7630297788012 1158.265463692241 1243.1378032264474 C1158.2682426630079 1242.516408025701 1157.7591984272406 1242.0027902951506 1157.1378032264943 1242.0000113243836 C1156.5125766741403 1241.9972152192488 1155.9972152192954 1242.5125766740937 1156.0000113244305 1243.1378032264474 "></path>\
            	    </defs>\
            	    <g style="mix-blend-mode:normal">\
            	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_10-d1224" fill="#000000" fill-opacity="1.0"></use>\
            	    </g>\
            	  </g>\
            	</svg>\
\
            </div>\
          </div>\
        </div>\
        <div id="s-Path_4" class="path firer commentable non-processed" customid="Path"   datasizewidth="19.0px" datasizeheight="18.9px" dataX="1027.0" dataY="1239.0"  >\
          <div class="borderLayer">\
          	<div class="imageViewport">\
            	<?xml version="1.0" encoding="UTF-8"?>\
            	<svg xmlns="http://www.w3.org/2000/svg" width="19.0" height="18.884960174560547" viewBox="1027.0 1239.0 19.0 18.884960174560547" preserveAspectRatio="none">\
            	  <g>\
            	    <defs>\
            	      <path id="s-Path_4-d1224" d="M1045.9999999999998 1248.4999999999998 C1045.9999999999998 1243.2527343183756 1041.7472653985021 1239.0 1036.5 1239.0 C1031.2527346014977 1239.0 1027.0 1243.2527343183756 1027.0 1248.4999999999998 C1027.0 1253.2425782382486 1030.4734374433756 1257.172460824251 1035.015625 1257.8849607110021 L1035.015625 1251.2460937499998 L1032.603515625 1251.2460937499998 L1032.603515625 1248.4999999999998 L1035.015625 1248.4999999999998 L1035.015625 1246.4070314764977 C1035.015625 1244.0264647305012 1036.4332030117512 1242.7109375 1038.604102015495 1242.7109375 C1039.643164515495 1242.7109375 1040.7304691746829 1242.896484375 1040.7304691746829 1242.896484375 L1040.7304691746829 1245.234375 L1039.531836390495 1245.234375 C1038.3517582938073 1245.234375 1037.9843754246829 1245.96728515625 1037.9843754246829 1246.71875 L1037.9843754246829 1248.4999999999998 L1040.6191410496829 1248.4999999999998 L1040.1979496292768 1251.2460937499998 L1037.9843749999998 1251.2460937499998 L1037.9843749999998 1257.8849607110021 C1042.5265622735021 1257.172461390495 1045.9999999999998 1253.2425776720045 1045.9999999999998 1248.4999999999998 Z "></path>\
            	    </defs>\
            	    <g style="mix-blend-mode:normal">\
            	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_4-d1224" fill="#000000" fill-opacity="1.0"></use>\
            	    </g>\
            	  </g>\
            	</svg>\
\
            </div>\
          </div>\
        </div>\
        <div id="s-Path_5" class="path firer commentable non-processed" customid="Path"   datasizewidth="8.1px" datasizeheight="15.3px" dataX="1033.0" dataY="1243.0"  >\
          <div class="borderLayer">\
          	<div class="imageViewport">\
            	<?xml version="1.0" encoding="UTF-8"?>\
            	<svg xmlns="http://www.w3.org/2000/svg" width="8.126953125" height="15.2890625" viewBox="1033.0 1243.0 8.126953125 15.2890625" preserveAspectRatio="none">\
            	  <g>\
            	    <defs>\
            	      <path id="s-Path_5-d1224" d="M1040.5944333672523 1251.53515625 L1041.015625 1248.7890625 L1038.380859375 1248.7890625 L1038.380859375 1247.0078125 C1038.380859375 1246.25634765625 1038.748242173344 1245.5234375 1039.9283203408122 1245.5234375 L1041.126953125 1245.5234375 L1041.126953125 1243.185546875 C1041.126953125 1243.185546875 1040.0396484658122 1243.0 1039.0005859658122 1243.0 C1036.8296875283122 1243.0 1035.412109516561 1244.3155273720622 1035.412109516561 1246.6960936933756 L1035.412109516561 1248.7890625 L1033.0 1248.7890625 L1033.0 1251.53515625 L1035.412109375 1251.53515625 L1035.412109375 1258.1740232110021 C1035.896386725828 1258.2500974279826 1036.391796860844 1258.289062269963 1036.896484375 1258.289062269963 C1037.401171889156 1258.289062269963 1037.8965820595622 1258.2500974279826 1038.380859375 1258.1740232110021 L1038.380859375 1251.53515625 L1040.5944333672523 1251.53515625 Z "></path>\
            	    </defs>\
            	    <g style="mix-blend-mode:normal">\
            	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_5-d1224" fill="#FFFFFF" fill-opacity="1.0"></use>\
            	    </g>\
            	  </g>\
            	</svg>\
\
            </div>\
          </div>\
        </div>\
        <div id="s-Path_11" class="path firer commentable non-processed" customid="bg"   datasizewidth="19.2px" datasizeheight="19.2px" dataX="1179.0" dataY="1239.0"  >\
          <div class="borderLayer">\
          	<div class="imageViewport">\
            	<?xml version="1.0" encoding="UTF-8"?>\
            	<svg xmlns="http://www.w3.org/2000/svg" width="19.248985290527344" height="19.20000648498535" viewBox="1179.0 1239.0 19.248985290527344 19.20000648498535" preserveAspectRatio="none">\
            	  <g>\
            	    <defs>\
            	      <path id="s-Path_11-d1224" d="M1194.085718805517 1258.2000066017597 L1183.163266656598 1258.2000066017597 C1180.861225186959 1258.2000066017597 1179.0 1256.3387815315773 1179.0 1254.0367399451618 L1179.0 1243.163266656598 C1179.0 1240.8612250701826 1180.8612250701826 1239.0 1183.163266656598 1239.0 L1194.085718805517 1239.0 C1196.3877602751559 1239.0 1198.248985462115 1240.8612250701826 1198.248985462115 1243.163266656598 L1198.248985462115 1254.085718805517 C1198.2000066017597 1256.3387818819067 1196.3387818819065 1258.2000066017597 1194.085718805517 1258.2000066017597 Z "></path>\
            	    </defs>\
            	    <g style="mix-blend-mode:normal">\
            	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_11-d1224" fill="#222221" fill-opacity="1.0"></use>\
            	    </g>\
            	  </g>\
            	</svg>\
\
            </div>\
          </div>\
        </div>\
        <div id="s-Path_12" class="path firer commentable non-processed" customid="i"   datasizewidth="2.4px" datasizeheight="7.8px" dataX="1183.0" dataY="1246.0"  >\
          <div class="borderLayer">\
          	<div class="imageViewport">\
            	<?xml version="1.0" encoding="UTF-8"?>\
            	<svg xmlns="http://www.w3.org/2000/svg" width="2.40000057220459" height="7.78775691986084" viewBox="1183.0 1246.0 2.40000057220459 7.78775691986084" preserveAspectRatio="none">\
            	  <g>\
            	    <defs>\
            	      <path id="s-Path_12-d1224" d="M1183.0 1246.0 L1185.4000008252199 1246.0 L1185.4000008252199 1253.787757441382 L1183.0 1253.787757441382 Z "></path>\
            	    </defs>\
            	    <g style="mix-blend-mode:normal">\
            	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_12-d1224" fill="#FFFFFF" fill-opacity="1.0"></use>\
            	    </g>\
            	  </g>\
            	</svg>\
\
            </div>\
          </div>\
        </div>\
        <div id="s-Path_13" class="path firer commentable non-processed" customid="."   datasizewidth="2.8px" datasizeheight="2.8px" dataX="1183.0" dataY="1242.0"  >\
          <div class="borderLayer">\
          	<div class="imageViewport">\
            	<?xml version="1.0" encoding="UTF-8"?>\
            	<svg xmlns="http://www.w3.org/2000/svg" width="2.840817451477051" height="2.840817451477051" viewBox="1182.9999995231628 1242.0 2.840817451477051 2.840817451477051" preserveAspectRatio="none">\
            	  <g>\
            	    <defs>\
            	      <path id="s-Path_13-d1224" d="M1184.4204086707264 1244.8408173414527 C1185.2040824059989 1244.8408173414527 1185.8408173414527 1244.2040824643873 1185.8408173414527 1243.4204086707264 C1185.8408173414527 1242.6367348770657 1185.2040824643873 1242.0 1184.4204086707264 1242.0 C1183.636734935454 1242.0 1183.0 1242.6367348770657 1183.0 1243.4204086707264 C1183.0 1244.2040824643873 1183.636734760289 1244.8408173414527 1184.4204086707264 1244.8408173414527 Z "></path>\
            	    </defs>\
            	    <g style="mix-blend-mode:normal">\
            	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_13-d1224" fill="#FFFFFF" fill-opacity="1.0"></use>\
            	    </g>\
            	  </g>\
            	</svg>\
\
            </div>\
          </div>\
        </div>\
        <div id="s-Path_14" class="path firer commentable non-processed" customid="n"   datasizewidth="7.5px" datasizeheight="8.0px" dataX="1188.0" dataY="1246.0"  >\
          <div class="borderLayer">\
          	<div class="imageViewport">\
            	<?xml version="1.0" encoding="UTF-8"?>\
            	<svg xmlns="http://www.w3.org/2000/svg" width="7.4938812255859375" height="8.032655715942383" viewBox="1187.9999992847443 1246.0 7.4938812255859375 8.032655715942383" preserveAspectRatio="none">\
            	  <g>\
            	    <defs>\
            	      <path id="s-Path_14-d1224" d="M1190.3020415864155 1249.9183686179745 C1190.3020415864155 1248.8408172246764 1190.7918376636621 1248.1551027865967 1191.7714298181559 1248.1551027865967 C1192.653062733845 1248.1551027865967 1193.0938792500776 1248.7918376636621 1193.0938792500776 1249.9183686179745 C1193.0938792500776 1251.044899572287 1193.0938792500776 1253.9836761525444 1193.0938792500776 1253.9836761525444 L1195.4938800752977 1253.9836761525444 C1195.4938800752977 1253.9836761525444 1195.4938800752977 1251.1428588110916 1195.4938800752977 1249.0857153800762 C1195.4938800752977 1247.0285719490607 1194.3183694431948 1246.0 1192.653062733845 1246.0 C1190.9877560244952 1246.0 1190.3020414696389 1247.2734697541312 1190.3020414696389 1247.2734697541312 L1190.3020414696389 1246.2448980386234 L1188.0 1246.2448980386234 L1188.0 1254.0326554800054 L1190.3020414696389 1254.0326554800054 C1190.3020415864155 1253.9836766196502 1190.3020415864155 1251.0938790165246 1190.3020415864155 1249.9183686179745 Z "></path>\
            	    </defs>\
            	    <g style="mix-blend-mode:normal">\
            	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_14-d1224" fill="#FFFFFF" fill-opacity="1.0"></use>\
            	    </g>\
            	  </g>\
            	</svg>\
\
            </div>\
          </div>\
        </div>\
      </div>\
\
\
      <div id="s-Image_15" class="image firer ie-background commentable non-processed" customid="eugto logo 2"   datasizewidth="84.9px" datasizeheight="65.1px" dataX="13.5" dataY="1215.4"   alt="image">\
        <div class="borderLayer">\
        	<div class="imageViewport">\
        		<img src="./images/d8ee76cf-76a7-4b43-a236-b152825d306e.png" />\
        	</div>\
        </div>\
      </div>\
\
      <div id="s-Paragraph_17" class="richtext autofit firer ie-background commentable non-processed" customid="Paragraph"   datasizewidth="1.0px" datasizeheight="1.0px" dataX="98.4" dataY="1237.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Paragraph_17_0"></span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Dynamic_Panel_2" class="dynamicpanel firer ie-background commentable non-processed" customid="Overview" datasizewidth="365.5px" datasizeheight="340.6px" dataX="969.0" dataY="216.0" >\
        <div id="s-Panel_6" class="panel default firer ie-background commentable non-processed" customid="Overview Normal"  datasizewidth="365.5px" datasizeheight="366.6px" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
          	<div class="layoutWrapper scrollable">\
          	  <div class="paddingLayer">\
                <div class="freeLayout">\
                <div id="s-Group_9" class="group firer ie-background commentable non-processed" customid="Info" datasizewidth="0.0px" datasizeheight="0.0px" >\
                  <div id="s-Group_10" class="group firer ie-background commentable non-processed" customid="Button" datasizewidth="0.0px" datasizeheight="0.0px" >\
                    <div id="s-Button_2" class="button multiline manualfit firer click commentable non-processed" customid="Button"   datasizewidth="280.0px" datasizeheight="62.9px" dataX="0.3" dataY="270.7" >\
                      <div class="backgroundLayer">\
                        <div class="colorLayer"></div>\
                        <div class="imageLayer"></div>\
                      </div>\
                      <div class="borderLayer">\
                        <div class="paddingLayer">\
                          <div class="content">\
                            <div class="valign">\
                              <span id="rtr-s-Button_2_0">READ MORE</span>\
                            </div>\
                          </div>\
                        </div>\
                      </div>\
                    </div>\
                    <div id="s-Path_3" class="path firer click commentable non-processed" customid="arrow"   datasizewidth="13.6px" datasizeheight="22.2px" dataX="237.5" dataY="290.8"  >\
                      <div class="borderLayer">\
                      	<div class="imageViewport">\
                        	<?xml version="1.0" encoding="UTF-8"?>\
                        	<svg xmlns="http://www.w3.org/2000/svg" width="13.612892150878906" height="22.196514129638672" viewBox="237.51513496906057 290.8227620355316 13.612892150878906 22.196514129638672" preserveAspectRatio="none">\
                        	  <g>\
                        	    <defs>\
                        	      <path id="s-Path_3-d1224" d="M249.45960356835016 304.30237711115 C249.84770045403246 303.8508191436217 250.4586908143161 303.8508191436217 250.8467876999984 304.30237711115 C251.22177319103065 304.7539350786783 251.22177319103065 305.46483376260875 250.8467876999984 305.91639173013704 L245.03407532716386 312.6806079771208 C244.8540123597928 312.8901145992372 244.6040220150713 313.01927645276703 244.32693482627965 313.01927645276703 C244.049847637488 313.01927645276703 243.7998573188165 312.8901145992372 243.61892024457543 312.6806079771208 L237.80620787174087 305.91639173013704 C237.41811098605857 305.46483376260875 237.41811098605857 304.7539350786783 237.80620787174087 304.30237711115 C238.1943047574232 303.8508191436217 238.80529511770683 303.8508191436217 239.19339200338914 304.30237711115 L243.341832821334 309.1454380380728 L243.341832821334 291.95267390307555 C243.3409590531137 291.3231370880031 243.78499731967685 290.8227620355316 244.3260606933597 290.8227620355316 C244.8671237023429 290.8227620355316 245.29717693628552 291.3231370880031 245.29717693628552 291.95267390307555 L245.29717693628552 309.144420483157 L249.45960356835016 304.30237711115 Z "></path>\
                        	    </defs>\
                        	    <g transform="rotate(270.0 244.32158101287587 301.9210192441493)" style="mix-blend-mode:normal">\
                        	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_3-d1224" fill="#FFFFFF" fill-opacity="1.0"></use>\
                        	    </g>\
                        	  </g>\
                        	</svg>\
\
                        </div>\
                      </div>\
                    </div>\
                  </div>\
\
                  <div id="s-Paragraph_2" class="richtext manualfit firer ie-background commentable non-processed" customid="H1"   datasizewidth="380.2px" datasizeheight="208.8px" dataX="0.0" dataY="0.0" >\
                    <div class="backgroundLayer">\
                      <div class="colorLayer"></div>\
                      <div class="imageLayer"></div>\
                    </div>\
                    <div class="borderLayer">\
                      <div class="paddingLayer">\
                        <div class="content">\
                          <div class="valign">\
                            <span id="rtr-s-Paragraph_2_0">OVERVIEW</span>\
                          </div>\
                        </div>\
                      </div>\
                    </div>\
                  </div>\
                  <div id="s-Paragraph_3" class="richtext manualfit firer ie-background commentable non-processed" customid="H2"   datasizewidth="329.6px" datasizeheight="215.0px" dataX="14.8" dataY="56.0" >\
                    <div class="backgroundLayer">\
                      <div class="colorLayer"></div>\
                      <div class="imageLayer"></div>\
                    </div>\
                    <div class="borderLayer">\
                      <div class="paddingLayer">\
                        <div class="content">\
                          <div class="valign">\
                            <span id="rtr-s-Paragraph_3_0">&quot;The Golden State&quot; has long been a popular nickname for California, and it was officially adopted as the state nickname in 1968. With beautiful beaches, pristine parks and hiking trails, stunning homes, a people-focused government, diverse culture, and population, the quality of life outweighs the costs for many Americans who enjoy living in California.</span>\
                          </div>\
                        </div>\
                      </div>\
                    </div>\
                  </div>\
                </div>\
\
                </div>\
\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Panel_7" class="panel hidden firer ie-background commentable non-processed" customid="Overview Bell"  datasizewidth="365.5px" datasizeheight="340.6px" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
          	<div class="layoutWrapper scrollable">\
          	  <div class="paddingLayer">\
                <div class="freeLayout">\
                <div id="s-Group_5" class="group firer ie-background commentable non-processed" customid="Info" datasizewidth="0.0px" datasizeheight="0.0px" >\
                  <div id="s-Group_13" class="group firer ie-background commentable non-processed" customid="Button" datasizewidth="0.0px" datasizeheight="0.0px" >\
                    <div id="s-Button_3" class="button multiline manualfit firer click commentable non-processed" customid="Button"   datasizewidth="280.0px" datasizeheight="62.9px" dataX="0.3" dataY="270.7" >\
                      <div class="backgroundLayer">\
                        <div class="colorLayer"></div>\
                        <div class="imageLayer"></div>\
                      </div>\
                      <div class="borderLayer">\
                        <div class="paddingLayer">\
                          <div class="content">\
                            <div class="valign">\
                              <span id="rtr-s-Button_3_0">READ MORE</span>\
                            </div>\
                          </div>\
                        </div>\
                      </div>\
                    </div>\
                    <div id="s-Path_16" class="path firer click commentable non-processed" customid="arrow"   datasizewidth="13.6px" datasizeheight="22.2px" dataX="237.5" dataY="290.8"  >\
                      <div class="borderLayer">\
                      	<div class="imageViewport">\
                        	<?xml version="1.0" encoding="UTF-8"?>\
                        	<svg xmlns="http://www.w3.org/2000/svg" width="13.612892150878906" height="22.196514129638672" viewBox="237.51513496906057 290.82276203553147 13.612892150878906 22.196514129638672" preserveAspectRatio="none">\
                        	  <g>\
                        	    <defs>\
                        	      <path id="s-Path_16-d1224" d="M249.45960356835016 304.3023771111499 C249.84770045403246 303.8508191436216 250.4586908143161 303.8508191436216 250.8467876999984 304.3023771111499 C251.22177319103065 304.7539350786782 251.22177319103065 305.46483376260863 250.8467876999984 305.9163917301369 L245.03407532716386 312.6806079771207 C244.8540123597928 312.8901145992371 244.6040220150713 313.0192764527669 244.32693482627965 313.0192764527669 C244.049847637488 313.0192764527669 243.7998573188165 312.8901145992371 243.61892024457543 312.6806079771207 L237.80620787174087 305.9163917301369 C237.41811098605857 305.46483376260863 237.41811098605857 304.7539350786782 237.80620787174087 304.3023771111499 C238.1943047574232 303.8508191436216 238.80529511770683 303.8508191436216 239.19339200338914 304.3023771111499 L243.341832821334 309.1454380380727 L243.341832821334 291.95267390307544 C243.3409590531137 291.32313708800297 243.78499731967685 290.82276203553147 244.3260606933597 290.82276203553147 C244.8671237023429 290.82276203553147 245.29717693628552 291.32313708800297 245.29717693628552 291.95267390307544 L245.29717693628552 309.14442048315686 L249.45960356835016 304.3023771111499 Z "></path>\
                        	    </defs>\
                        	    <g transform="rotate(270.0 244.32158101287587 301.9210192441492)" style="mix-blend-mode:normal">\
                        	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_16-d1224" fill="#FFFFFF" fill-opacity="1.0"></use>\
                        	    </g>\
                        	  </g>\
                        	</svg>\
\
                        </div>\
                      </div>\
                    </div>\
                  </div>\
\
                  <div id="s-Paragraph_26" class="richtext manualfit firer ie-background commentable non-processed" customid="H1"   datasizewidth="380.2px" datasizeheight="208.8px" dataX="0.0" dataY="-0.0" >\
                    <div class="backgroundLayer">\
                      <div class="colorLayer"></div>\
                      <div class="imageLayer"></div>\
                    </div>\
                    <div class="borderLayer">\
                      <div class="paddingLayer">\
                        <div class="content">\
                          <div class="valign">\
                            <span id="rtr-s-Paragraph_26_0">OVERVIEW</span>\
                          </div>\
                        </div>\
                      </div>\
                    </div>\
                  </div>\
                  <div id="s-Paragraph_27" class="richtext manualfit firer ie-background commentable non-processed" customid="H2"   datasizewidth="329.6px" datasizeheight="200.0px" dataX="14.8" dataY="62.0" >\
                    <div class="backgroundLayer">\
                      <div class="colorLayer"></div>\
                      <div class="imageLayer"></div>\
                    </div>\
                    <div class="borderLayer">\
                      <div class="paddingLayer">\
                        <div class="content">\
                          <div class="valign">\
                            <span id="rtr-s-Paragraph_27_0">The Ciry of Bell, located on the east bank of the Los Angeles River in southeast Los Angeles County, is a warm and friendly town made up of young families, small businesses, and an industrial district. Because it is located in the heart of the central Los Angeles industrial market, Bell is known as the key to industry.</span>\
                          </div>\
                        </div>\
                      </div>\
                    </div>\
                  </div>\
                </div>\
\
                </div>\
\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Paragraph_28" class="richtext autofit firer ie-background commentable non-processed" customid="URBANIZATION WITH ENVIRON"   datasizewidth="305.7px" datasizeheight="17.0px" dataX="88.1" dataY="1240.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Paragraph_28_0">URBANIZATION WITH ENVIRONMENT AT HEART.</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Dynamic_Panel_1" class="dynamicpanel firer ie-background commentable non-processed" customid="Environmental Impacts" datasizewidth="866.5px" datasizeheight="267.0px" dataX="46.0" dataY="908.2" >\
        <div id="s-Panel_10" class="panel hidden firer ie-background commentable non-processed" customid="Carbon Footprint"  datasizewidth="866.5px" datasizeheight="267.0px" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
          	<div class="layoutWrapper scrollable">\
          	  <div class="paddingLayer">\
                <div class="freeLayout">\
                <div id="s-Rectangle_16" class="rectangle manualfit firer commentable non-processed" customid="Bg rect"   datasizewidth="885.5px" datasizeheight="327.7px" datasizewidthpx="885.5178527832014" datasizeheightpx="327.69229507100874" dataX="0.0" dataY="0.0" >\
                  <div class="backgroundLayer">\
                    <div class="colorLayer"></div>\
                    <div class="imageLayer"></div>\
                  </div>\
                  <div class="borderLayer">\
                    <div class="paddingLayer">\
                      <div class="content">\
                        <div class="valign">\
                          <span id="rtr-s-Rectangle_16_0"></span>\
                        </div>\
                      </div>\
                    </div>\
                  </div>\
                </div>\
                <div id="s-Rectangle_17" class="rectangle manualfit firer commentable non-processed" customid="Rectangle 2"   datasizewidth="836.5px" datasizeheight="220.7px" datasizewidthpx="836.517852783202" datasizeheightpx="220.6922950710076" dataX="30.0" dataY="46.3" >\
                  <div class="backgroundLayer">\
                    <div class="colorLayer"></div>\
                    <div class="imageLayer"></div>\
                  </div>\
                  <div class="borderLayer">\
                    <div class="paddingLayer">\
                      <div class="content">\
                        <div class="valign">\
                          <span id="rtr-s-Rectangle_17_0"></span>\
                        </div>\
                      </div>\
                    </div>\
                  </div>\
                </div>\
                <div id="s-Paragraph_29" class="richtext manualfit firer ie-background commentable non-processed" customid="H2"   datasizewidth="548.6px" datasizeheight="248.0px" dataX="52.0" dataY="79.7" >\
                  <div class="backgroundLayer">\
                    <div class="colorLayer"></div>\
                    <div class="imageLayer"></div>\
                  </div>\
                  <div class="borderLayer">\
                    <div class="paddingLayer">\
                      <div class="content">\
                        <div class="valign">\
                          <span id="rtr-s-Paragraph_29_0">Most affected City: </span><span id="rtr-s-Paragraph_29_1">East San Gabriel Valley, CA<br /></span><span id="rtr-s-Paragraph_29_2">Latitude: </span><span id="rtr-s-Paragraph_29_3">34.121428</span><span id="rtr-s-Paragraph_29_4"> &nbsp;| Longitude: </span><span id="rtr-s-Paragraph_29_5">-118.079896<br /><br /></span><span id="rtr-s-Paragraph_29_6"><br />Amount:</span><span id="rtr-s-Paragraph_29_7"> 31228.9026 tons/day<br /><br /></span>\
                        </div>\
                      </div>\
                    </div>\
                  </div>\
                </div>\
                <div id="s-Paragraph_30" class="richtext manualfit firer ie-background commentable non-processed" customid="GENERATED RESULTS"   datasizewidth="406.2px" datasizeheight="48.0px" dataX="14.0" dataY="9.0" >\
                  <div class="backgroundLayer">\
                    <div class="colorLayer"></div>\
                    <div class="imageLayer"></div>\
                  </div>\
                  <div class="borderLayer">\
                    <div class="paddingLayer">\
                      <div class="content">\
                        <div class="valign">\
                          <span id="rtr-s-Paragraph_30_0">GENERATED RESULTS</span>\
                        </div>\
                      </div>\
                    </div>\
                  </div>\
                </div>\
\
                <div id="s-Image_14" class="image firer ie-background commentable non-processed" customid="Image 2"   datasizewidth="170.8px" datasizeheight="173.8px" dataX="671.0" dataY="77.0"   alt="image">\
                  <div class="borderLayer">\
                  	<div class="imageViewport">\
                  		<img src="./images/c0dd3f14-2be5-4c49-895d-e82cf85a45fe.png" />\
                  	</div>\
                  </div>\
                </div>\
\
                </div>\
\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Panel_1" class="panel default firer ie-background commentable non-processed" customid="Normal Panel"  datasizewidth="866.5px" datasizeheight="267.0px" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
          	<div class="layoutWrapper scrollable">\
          	  <div class="paddingLayer">\
                <div class="freeLayout">\
                <div id="s-Rectangle_2" class="rectangle manualfit firer commentable non-processed" customid="Bg rect"   datasizewidth="885.5px" datasizeheight="327.7px" datasizewidthpx="885.5178527832014" datasizeheightpx="327.69229507100874" dataX="0.0" dataY="0.0" >\
                  <div class="backgroundLayer">\
                    <div class="colorLayer"></div>\
                    <div class="imageLayer"></div>\
                  </div>\
                  <div class="borderLayer">\
                    <div class="paddingLayer">\
                      <div class="content">\
                        <div class="valign">\
                          <span id="rtr-s-Rectangle_2_0"></span>\
                        </div>\
                      </div>\
                    </div>\
                  </div>\
                </div>\
                <div id="s-Rectangle_1" class="rectangle manualfit firer commentable non-processed" customid="Rectangle 2"   datasizewidth="836.5px" datasizeheight="220.7px" datasizewidthpx="836.517852783202" datasizeheightpx="220.6922950710076" dataX="30.0" dataY="46.3" >\
                  <div class="backgroundLayer">\
                    <div class="colorLayer"></div>\
                    <div class="imageLayer"></div>\
                  </div>\
                  <div class="borderLayer">\
                    <div class="paddingLayer">\
                      <div class="content">\
                        <div class="valign">\
                          <span id="rtr-s-Rectangle_1_0"></span>\
                        </div>\
                      </div>\
                    </div>\
                  </div>\
                </div>\
                <div id="s-Paragraph_8" class="richtext manualfit firer ie-background commentable non-processed" customid="H2"   datasizewidth="548.6px" datasizeheight="248.0px" dataX="52.0" dataY="79.7" >\
                  <div class="backgroundLayer">\
                    <div class="colorLayer"></div>\
                    <div class="imageLayer"></div>\
                  </div>\
                  <div class="borderLayer">\
                    <div class="paddingLayer">\
                      <div class="content">\
                        <div class="valign">\
                          <span id="rtr-s-Paragraph_8_0">Most affected City: <br />Latitude: &nbsp; &nbsp; &nbsp; &nbsp; | Longitude:<br /></span><span id="rtr-s-Paragraph_8_1"><br /></span><span id="rtr-s-Paragraph_8_2"><br />Amount:</span><span id="rtr-s-Paragraph_8_3"> <br /><br /></span>\
                        </div>\
                      </div>\
                    </div>\
                  </div>\
                </div>\
                <div id="s-Paragraph_5" class="richtext manualfit firer ie-background commentable non-processed" customid="GENERATED RESULTS"   datasizewidth="406.2px" datasizeheight="48.0px" dataX="14.0" dataY="9.0" >\
                  <div class="backgroundLayer">\
                    <div class="colorLayer"></div>\
                    <div class="imageLayer"></div>\
                  </div>\
                  <div class="borderLayer">\
                    <div class="paddingLayer">\
                      <div class="content">\
                        <div class="valign">\
                          <span id="rtr-s-Paragraph_5_0">GENERATED RESULTS</span>\
                        </div>\
                      </div>\
                    </div>\
                  </div>\
                </div>\
                </div>\
\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Panel_2" class="panel hidden firer ie-background commentable non-processed" customid="Road Traffic"  datasizewidth="866.5px" datasizeheight="267.0px" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
          	<div class="layoutWrapper scrollable">\
          	  <div class="paddingLayer">\
                <div class="freeLayout">\
                <div id="s-Rectangle_10" class="rectangle manualfit firer commentable non-processed" customid="Bg rect"   datasizewidth="885.5px" datasizeheight="327.7px" datasizewidthpx="885.5178527832014" datasizeheightpx="327.69229507100874" dataX="0.0" dataY="0.0" >\
                  <div class="backgroundLayer">\
                    <div class="colorLayer"></div>\
                    <div class="imageLayer"></div>\
                  </div>\
                  <div class="borderLayer">\
                    <div class="paddingLayer">\
                      <div class="content">\
                        <div class="valign">\
                          <span id="rtr-s-Rectangle_10_0"></span>\
                        </div>\
                      </div>\
                    </div>\
                  </div>\
                </div>\
                <div id="s-Rectangle_11" class="rectangle manualfit firer commentable non-processed" customid="Rectangle 2"   datasizewidth="836.5px" datasizeheight="220.7px" datasizewidthpx="836.517852783202" datasizeheightpx="220.6922950710076" dataX="30.0" dataY="46.3" >\
                  <div class="backgroundLayer">\
                    <div class="colorLayer"></div>\
                    <div class="imageLayer"></div>\
                  </div>\
                  <div class="borderLayer">\
                    <div class="paddingLayer">\
                      <div class="content">\
                        <div class="valign">\
                          <span id="rtr-s-Rectangle_11_0"></span>\
                        </div>\
                      </div>\
                    </div>\
                  </div>\
                </div>\
                <div id="s-Paragraph_20" class="richtext manualfit firer ie-background commentable non-processed" customid="H2"   datasizewidth="548.6px" datasizeheight="248.0px" dataX="52.0" dataY="79.7" >\
                  <div class="backgroundLayer">\
                    <div class="colorLayer"></div>\
                    <div class="imageLayer"></div>\
                  </div>\
                  <div class="borderLayer">\
                    <div class="paddingLayer">\
                      <div class="content">\
                        <div class="valign">\
                          <span id="rtr-s-Paragraph_20_0">Most affected City: </span><span id="rtr-s-Paragraph_20_1">Artesia, CA<br /></span><span id="rtr-s-Paragraph_20_2">Latitude: </span><span id="rtr-s-Paragraph_20_3">33.8658484 </span><span id="rtr-s-Paragraph_20_4"> | Longitude: </span><span id="rtr-s-Paragraph_20_5">-118.0831212<br /><br /></span><span id="rtr-s-Paragraph_20_6"><br />Amount:</span><span id="rtr-s-Paragraph_20_7"> 6461003.755 vehicle/day<br /><br /></span>\
                        </div>\
                      </div>\
                    </div>\
                  </div>\
                </div>\
                <div id="s-Paragraph_21" class="richtext manualfit firer ie-background commentable non-processed" customid="GENERATED RESULTS"   datasizewidth="406.2px" datasizeheight="48.0px" dataX="14.0" dataY="9.0" >\
                  <div class="backgroundLayer">\
                    <div class="colorLayer"></div>\
                    <div class="imageLayer"></div>\
                  </div>\
                  <div class="borderLayer">\
                    <div class="paddingLayer">\
                      <div class="content">\
                        <div class="valign">\
                          <span id="rtr-s-Paragraph_21_0">GENERATED RESULTS</span>\
                        </div>\
                      </div>\
                    </div>\
                  </div>\
                </div>\
\
                <div id="s-Image_11" class="image firer ie-background commentable non-processed" customid="Image 3"   datasizewidth="170.8px" datasizeheight="171.6px" dataX="664.0" dataY="77.8"   alt="image">\
                  <div class="borderLayer">\
                  	<div class="imageViewport">\
                  		<img src="./images/58f5d7fd-c107-40b9-881b-9c0f0e75c339.png" />\
                  	</div>\
                  </div>\
                </div>\
\
                </div>\
\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Panel_3" class="panel hidden firer ie-background commentable non-processed" customid="AQI"  datasizewidth="866.5px" datasizeheight="267.0px" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
          	<div class="layoutWrapper scrollable">\
          	  <div class="paddingLayer">\
                <div class="freeLayout">\
                <div id="s-Rectangle_12" class="rectangle manualfit firer commentable non-processed" customid="Bg rect"   datasizewidth="885.5px" datasizeheight="327.7px" datasizewidthpx="885.5178527832014" datasizeheightpx="327.69229507100874" dataX="0.0" dataY="0.0" >\
                  <div class="backgroundLayer">\
                    <div class="colorLayer"></div>\
                    <div class="imageLayer"></div>\
                  </div>\
                  <div class="borderLayer">\
                    <div class="paddingLayer">\
                      <div class="content">\
                        <div class="valign">\
                          <span id="rtr-s-Rectangle_12_0"></span>\
                        </div>\
                      </div>\
                    </div>\
                  </div>\
                </div>\
                <div id="s-Rectangle_13" class="rectangle manualfit firer commentable non-processed" customid="Rectangle 2"   datasizewidth="836.5px" datasizeheight="220.7px" datasizewidthpx="836.517852783202" datasizeheightpx="220.6922950710076" dataX="30.0" dataY="46.3" >\
                  <div class="backgroundLayer">\
                    <div class="colorLayer"></div>\
                    <div class="imageLayer"></div>\
                  </div>\
                  <div class="borderLayer">\
                    <div class="paddingLayer">\
                      <div class="content">\
                        <div class="valign">\
                          <span id="rtr-s-Rectangle_13_0"></span>\
                        </div>\
                      </div>\
                    </div>\
                  </div>\
                </div>\
                <div id="s-Paragraph_22" class="richtext manualfit firer ie-background commentable non-processed" customid="H2"   datasizewidth="548.6px" datasizeheight="248.0px" dataX="52.0" dataY="79.7" >\
                  <div class="backgroundLayer">\
                    <div class="colorLayer"></div>\
                    <div class="imageLayer"></div>\
                  </div>\
                  <div class="borderLayer">\
                    <div class="paddingLayer">\
                      <div class="content">\
                        <div class="valign">\
                          <span id="rtr-s-Paragraph_22_0">Most affected City: </span><span id="rtr-s-Paragraph_22_1">Artesia, CA<br /></span><span id="rtr-s-Paragraph_22_2">Latitude: </span><span id="rtr-s-Paragraph_22_3">33.8658484 </span><span id="rtr-s-Paragraph_22_4"> | Longitude: </span><span id="rtr-s-Paragraph_22_5">-118.0831212<br /><br /></span><span id="rtr-s-Paragraph_22_6"><br />Amount: </span><span id="rtr-s-Paragraph_22_7">241</span><span id="rtr-s-Paragraph_22_8"> (unitless)<br /><br /></span>\
                        </div>\
                      </div>\
                    </div>\
                  </div>\
                </div>\
                <div id="s-Paragraph_23" class="richtext manualfit firer ie-background commentable non-processed" customid="GENERATED RESULTS"   datasizewidth="406.2px" datasizeheight="48.0px" dataX="14.0" dataY="9.0" >\
                  <div class="backgroundLayer">\
                    <div class="colorLayer"></div>\
                    <div class="imageLayer"></div>\
                  </div>\
                  <div class="borderLayer">\
                    <div class="paddingLayer">\
                      <div class="content">\
                        <div class="valign">\
                          <span id="rtr-s-Paragraph_23_0">GENERATED RESULTS</span>\
                        </div>\
                      </div>\
                    </div>\
                  </div>\
                </div>\
\
                <div id="s-Image_12" class="image firer ie-background commentable non-processed" customid="Image 4"   datasizewidth="170.8px" datasizeheight="170.9px" dataX="664.0" dataY="78.5"   alt="image">\
                  <div class="borderLayer">\
                  	<div class="imageViewport">\
                  		<img src="./images/cb07f12b-9851-4bd3-ab30-8379163bfb3f.png" />\
                  	</div>\
                  </div>\
                </div>\
\
                </div>\
\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Panel_5" class="panel hidden firer ie-background commentable non-processed" customid="Waste Generation"  datasizewidth="866.5px" datasizeheight="267.0px" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
          	<div class="layoutWrapper scrollable">\
          	  <div class="paddingLayer">\
                <div class="freeLayout">\
                <div id="s-Rectangle_14" class="rectangle manualfit firer commentable non-processed" customid="Bg rect"   datasizewidth="885.5px" datasizeheight="327.7px" datasizewidthpx="885.5178527832014" datasizeheightpx="327.69229507100874" dataX="0.0" dataY="0.0" >\
                  <div class="backgroundLayer">\
                    <div class="colorLayer"></div>\
                    <div class="imageLayer"></div>\
                  </div>\
                  <div class="borderLayer">\
                    <div class="paddingLayer">\
                      <div class="content">\
                        <div class="valign">\
                          <span id="rtr-s-Rectangle_14_0"></span>\
                        </div>\
                      </div>\
                    </div>\
                  </div>\
                </div>\
                <div id="s-Rectangle_15" class="rectangle manualfit firer commentable non-processed" customid="Rectangle 2"   datasizewidth="836.5px" datasizeheight="220.7px" datasizewidthpx="836.517852783202" datasizeheightpx="220.6922950710076" dataX="30.0" dataY="46.3" >\
                  <div class="backgroundLayer">\
                    <div class="colorLayer"></div>\
                    <div class="imageLayer"></div>\
                  </div>\
                  <div class="borderLayer">\
                    <div class="paddingLayer">\
                      <div class="content">\
                        <div class="valign">\
                          <span id="rtr-s-Rectangle_15_0"></span>\
                        </div>\
                      </div>\
                    </div>\
                  </div>\
                </div>\
                <div id="s-Paragraph_24" class="richtext manualfit firer ie-background commentable non-processed" customid="H2"   datasizewidth="548.6px" datasizeheight="248.0px" dataX="52.0" dataY="79.7" >\
                  <div class="backgroundLayer">\
                    <div class="colorLayer"></div>\
                    <div class="imageLayer"></div>\
                  </div>\
                  <div class="borderLayer">\
                    <div class="paddingLayer">\
                      <div class="content">\
                        <div class="valign">\
                          <span id="rtr-s-Paragraph_24_0">Most affected City: </span><span id="rtr-s-Paragraph_24_1">East San Gabriel Valley, CA<br /></span><span id="rtr-s-Paragraph_24_2">Latitude: </span><span id="rtr-s-Paragraph_24_3">34.121428</span><span id="rtr-s-Paragraph_24_4"> &nbsp;| Longitude: </span><span id="rtr-s-Paragraph_24_5">-118.079896<br /><br /></span><span id="rtr-s-Paragraph_24_6"><br />Amount: </span><span id="rtr-s-Paragraph_24_7">4934166.611</span><span id="rtr-s-Paragraph_24_8"> kg/day<br /><br /></span>\
                        </div>\
                      </div>\
                    </div>\
                  </div>\
                </div>\
                <div id="s-Paragraph_25" class="richtext manualfit firer ie-background commentable non-processed" customid="GENERATED RESULTS"   datasizewidth="406.2px" datasizeheight="48.0px" dataX="14.0" dataY="9.0" >\
                  <div class="backgroundLayer">\
                    <div class="colorLayer"></div>\
                    <div class="imageLayer"></div>\
                  </div>\
                  <div class="borderLayer">\
                    <div class="paddingLayer">\
                      <div class="content">\
                        <div class="valign">\
                          <span id="rtr-s-Paragraph_25_0">GENERATED RESULTS</span>\
                        </div>\
                      </div>\
                    </div>\
                  </div>\
                </div>\
\
                <div id="s-Image_13" class="image firer ie-background commentable non-processed" customid="Image 5"   datasizewidth="170.8px" datasizeheight="169.8px" dataX="664.0" dataY="79.7"   alt="image">\
                  <div class="borderLayer">\
                  	<div class="imageViewport">\
                  		<img src="./images/c759b685-246a-4633-a08d-76b1f1bb2dc3.png" />\
                  	</div>\
                  </div>\
                </div>\
\
                </div>\
\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Dynamic_Panel_3" class="dynamicpanel firer ie-background commentable non-processed" customid="Maps" datasizewidth="900.9px" datasizeheight="657.8px" dataX="55.9" dataY="230.0" >\
        <div id="s-Panel_4" class="panel default firer ie-background commentable non-processed" customid="Normal Map"  datasizewidth="900.9px" datasizeheight="657.8px" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
          	<div class="layoutWrapper scrollable">\
          	  <div class="paddingLayer">\
                <div class="freeLayout">\
                <div id="s-Browser_1" class="html firer ie-background commentable non-processed" datasizewidth="888.9px" datasizeheight="625.6px" dataX="6.0" dataY="0.0" >\
                  <div class="commentpanel hidden"></div>\
                  <div class="borderLayer">\
                    <iframe class="htmlwidget" srcdoc=\'<html>\
                  <head>\
                    <title></title>\
                    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8"></meta>\
                    <style>\
                        .google-maps {\
                            position: relative;\
                            overflow: hidden;\
                            width: 100% !important;\
                            height: 100% !important;\
                        }\
                        .google-maps iframe {\
                            position: absolute;\
                            top: 0;\
                            left: 0;\
                            width: 100% !important;\
                            height: 100% !important;\
                        }\
                    </style>\
                  </head>\
                <body style="position:absolute; width:100%; height:100%;">  \
                      <div class="google-maps">\
                          <iframe src="https://www.openstreetmap.org/export/embed.html?bbox=-122.05261230468751%2C32.54218257955074%2C-115.92224121093751%2C35.02999636902566&amp;layer=transportmap" width="100%" height="450" frameborder="0" style="border:0;" allowfullscreen=""></iframe>\
                      </div>\
                    </body>\
                </html>\
                \' width="100%" height="100%" frameborder="0" marginheight="0px" marginwidth="0px" scrolling="auto" sandbox="allow-scripts allow-same-origin">\
                      <p>Your browser does not support iframes, please update!</p>\
                    </iframe>\
                  </div>\
                </div>\
                </div>\
\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Panel_9" class="panel hidden firer ie-background commentable non-processed" customid="Carbon Footprint Initial"  datasizewidth="900.9px" datasizeheight="657.8px" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
          	<div class="layoutWrapper scrollable">\
          	  <div class="paddingLayer">\
                <div class="freeLayout">\
                <div id="s-Group_21" class="group firer ie-background commentable non-processed" customid="Group 14" datasizewidth="0.0px" datasizeheight="0.0px" >\
                  <div id="shapewrapper-s-Ellipse_12" customid="First page" class="shapewrapper shapewrapper-s-Ellipse_12 non-processed"   datasizewidth="13.0px" datasizeheight="13.0px" datasizewidthpx="13.0" datasizeheightpx="13.0" dataX="437.4" dataY="637.0" >\
                      <div class="backgroundLayer">\
                        <div class="colorLayer"></div>\
                        <div class="imageLayer"></div>\
                      </div>\
                      <svg version="1.1" baseProfile="full" xmlns="http://www.w3.org/2000/svg" id="svg-s-Ellipse_12" class="svgContainer" style="width:100%; height:100%;">\
                          <g>\
                              <g clip-path="url(#clip-s-Ellipse_12)">\
                                      <ellipse id="s-Ellipse_12" class="ellipse shape non-processed-shape manualfit firer click commentable non-processed" customid="First page" cx="6.5" cy="6.5" rx="6.5" ry="6.5">\
                                      </ellipse>\
                              </g>\
                          </g>\
                          <defs>\
                              <clipPath id="clip-s-Ellipse_12" class="clipPath">\
                                      <ellipse cx="6.5" cy="6.5" rx="6.5" ry="6.5">\
                                      </ellipse>\
                              </clipPath>\
                          </defs>\
                      </svg>\
                      <div class="paddingLayer">\
                          <div id="shapert-s-Ellipse_12" class="content firer" >\
                              <div class="valign">\
                                  <span id="rtr-s-Ellipse_12_0"></span>\
                              </div>\
                          </div>\
                      </div>\
                  </div>\
                  <div id="shapewrapper-s-Ellipse_13" customid="Second page" class="shapewrapper shapewrapper-s-Ellipse_13 non-processed"   datasizewidth="13.0px" datasizeheight="13.0px" datasizewidthpx="13.0" datasizeheightpx="13.0" dataX="456.0" dataY="637.0" >\
                      <div class="backgroundLayer">\
                        <div class="colorLayer"></div>\
                        <div class="imageLayer"></div>\
                      </div>\
                      <svg version="1.1" baseProfile="full" xmlns="http://www.w3.org/2000/svg" id="svg-s-Ellipse_13" class="svgContainer" style="width:100%; height:100%;">\
                          <g>\
                              <g clip-path="url(#clip-s-Ellipse_13)">\
                                      <ellipse id="s-Ellipse_13" class="ellipse shape non-processed-shape manualfit firer click commentable non-processed" customid="Second page" cx="6.5" cy="6.5" rx="6.5" ry="6.5">\
                                      </ellipse>\
                              </g>\
                          </g>\
                          <defs>\
                              <clipPath id="clip-s-Ellipse_13" class="clipPath">\
                                      <ellipse cx="6.5" cy="6.5" rx="6.5" ry="6.5">\
                                      </ellipse>\
                              </clipPath>\
                          </defs>\
                      </svg>\
                      <div class="paddingLayer">\
                          <div id="shapert-s-Ellipse_13" class="content firer" >\
                              <div class="valign">\
                                  <span id="rtr-s-Ellipse_13_0"></span>\
                              </div>\
                          </div>\
                      </div>\
                  </div>\
                </div>\
\
                <div id="s-Browser_7" class="html firer ie-background commentable non-processed" datasizewidth="888.9px" datasizeheight="625.6px" dataX="6.0" dataY="0.0" >\
                  <div class="commentpanel hidden"></div>\
                  <div class="borderLayer">\
                    <iframe class="htmlwidget" srcdoc=\'<html>\
                  <head>\
                    <title></title>\
                    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8"></meta>\
                    <style>\
                        .google-maps {\
                            position: relative;\
                            overflow: hidden;\
                            width: 100% !important;\
                            height: 100% !important;\
                        }\
                        .google-maps iframe {\
                            position: absolute;\
                            top: 0;\
                            left: 0;\
                            width: 100% !important;\
                            height: 100% !important;\
                        }\
                    </style>\
                  </head>\
                <body style="position:absolute; width:100%; height:100%;">  \
                      <div class="google-maps">\
                          <iframe src="https://eugto-datasets-host-fromdrive.on.drv.tw/Bell_CF_initial.html" width="100%" height="450" frameborder="0" style="border:0;" allowfullscreen=""></iframe>\
                      </div>\
                    </body>\
                </html>\
                \' width="100%" height="100%" frameborder="0" marginheight="0px" marginwidth="0px" scrolling="auto" sandbox="allow-scripts allow-same-origin">\
                      <p>Your browser does not support iframes, please update!</p>\
                    </iframe>\
                  </div>\
                </div>\
                </div>\
\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Panel_11" class="panel hidden firer ie-background commentable non-processed" customid="Carbon Footprint Final"  datasizewidth="900.9px" datasizeheight="657.8px" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
          	<div class="layoutWrapper scrollable">\
          	  <div class="paddingLayer">\
                <div class="freeLayout">\
                <div id="s-Group_22" class="group firer ie-background commentable non-processed" customid="Group 14" datasizewidth="0.0px" datasizeheight="0.0px" >\
                  <div id="shapewrapper-s-Ellipse_14" customid="First page" class="shapewrapper shapewrapper-s-Ellipse_14 non-processed"   datasizewidth="13.0px" datasizeheight="13.0px" datasizewidthpx="13.0" datasizeheightpx="13.0" dataX="437.4" dataY="637.0" >\
                      <div class="backgroundLayer">\
                        <div class="colorLayer"></div>\
                        <div class="imageLayer"></div>\
                      </div>\
                      <svg version="1.1" baseProfile="full" xmlns="http://www.w3.org/2000/svg" id="svg-s-Ellipse_14" class="svgContainer" style="width:100%; height:100%;">\
                          <g>\
                              <g clip-path="url(#clip-s-Ellipse_14)">\
                                      <ellipse id="s-Ellipse_14" class="ellipse shape non-processed-shape manualfit firer click commentable non-processed" customid="First page" cx="6.5" cy="6.5" rx="6.5" ry="6.5">\
                                      </ellipse>\
                              </g>\
                          </g>\
                          <defs>\
                              <clipPath id="clip-s-Ellipse_14" class="clipPath">\
                                      <ellipse cx="6.5" cy="6.5" rx="6.5" ry="6.5">\
                                      </ellipse>\
                              </clipPath>\
                          </defs>\
                      </svg>\
                      <div class="paddingLayer">\
                          <div id="shapert-s-Ellipse_14" class="content firer" >\
                              <div class="valign">\
                                  <span id="rtr-s-Ellipse_14_0"></span>\
                              </div>\
                          </div>\
                      </div>\
                  </div>\
                  <div id="shapewrapper-s-Ellipse_15" customid="Second page" class="shapewrapper shapewrapper-s-Ellipse_15 non-processed"   datasizewidth="13.0px" datasizeheight="13.0px" datasizewidthpx="13.0" datasizeheightpx="13.0" dataX="456.0" dataY="637.0" >\
                      <div class="backgroundLayer">\
                        <div class="colorLayer"></div>\
                        <div class="imageLayer"></div>\
                      </div>\
                      <svg version="1.1" baseProfile="full" xmlns="http://www.w3.org/2000/svg" id="svg-s-Ellipse_15" class="svgContainer" style="width:100%; height:100%;">\
                          <g>\
                              <g clip-path="url(#clip-s-Ellipse_15)">\
                                      <ellipse id="s-Ellipse_15" class="ellipse shape non-processed-shape manualfit firer click commentable non-processed" customid="Second page" cx="6.5" cy="6.5" rx="6.5" ry="6.5">\
                                      </ellipse>\
                              </g>\
                          </g>\
                          <defs>\
                              <clipPath id="clip-s-Ellipse_15" class="clipPath">\
                                      <ellipse cx="6.5" cy="6.5" rx="6.5" ry="6.5">\
                                      </ellipse>\
                              </clipPath>\
                          </defs>\
                      </svg>\
                      <div class="paddingLayer">\
                          <div id="shapert-s-Ellipse_15" class="content firer" >\
                              <div class="valign">\
                                  <span id="rtr-s-Ellipse_15_0"></span>\
                              </div>\
                          </div>\
                      </div>\
                  </div>\
                </div>\
\
                <div id="s-Browser_8" class="html firer ie-background commentable non-processed" datasizewidth="888.9px" datasizeheight="625.6px" dataX="6.0" dataY="0.0" >\
                  <div class="commentpanel hidden"></div>\
                  <div class="borderLayer">\
                    <iframe class="htmlwidget" srcdoc=\'<html>\
                  <head>\
                    <title></title>\
                    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8"></meta>\
                    <style>\
                        .google-maps {\
                            position: relative;\
                            overflow: hidden;\
                            width: 100% !important;\
                            height: 100% !important;\
                        }\
                        .google-maps iframe {\
                            position: absolute;\
                            top: 0;\
                            left: 0;\
                            width: 100% !important;\
                            height: 100% !important;\
                        }\
                    </style>\
                  </head>\
                <body style="position:absolute; width:100%; height:100%;">  \
                      <div class="google-maps">\
                          <iframe src="https://eugto-datasets-host-fromdrive.on.drv.tw/Bell_CF_final.html" width="100%" height="450" frameborder="0" style="border:0;" allowfullscreen=""></iframe>\
                      </div>\
                    </body>\
                </html>\
                \' width="100%" height="100%" frameborder="0" marginheight="0px" marginwidth="0px" scrolling="auto" sandbox="allow-scripts allow-same-origin">\
                      <p>Your browser does not support iframes, please update!</p>\
                    </iframe>\
                  </div>\
                </div>\
                </div>\
\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Panel_12" class="panel hidden firer ie-background commentable non-processed" customid="Road Traffic Initial"  datasizewidth="900.9px" datasizeheight="657.8px" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
          	<div class="layoutWrapper scrollable">\
          	  <div class="paddingLayer">\
                <div class="freeLayout">\
                <div id="s-Group_24" class="group firer ie-background commentable non-processed" customid="Group 14" datasizewidth="0.0px" datasizeheight="0.0px" >\
                  <div id="shapewrapper-s-Ellipse_18" customid="First page" class="shapewrapper shapewrapper-s-Ellipse_18 non-processed"   datasizewidth="13.0px" datasizeheight="13.0px" datasizewidthpx="13.0" datasizeheightpx="13.0" dataX="437.4" dataY="637.0" >\
                      <div class="backgroundLayer">\
                        <div class="colorLayer"></div>\
                        <div class="imageLayer"></div>\
                      </div>\
                      <svg version="1.1" baseProfile="full" xmlns="http://www.w3.org/2000/svg" id="svg-s-Ellipse_18" class="svgContainer" style="width:100%; height:100%;">\
                          <g>\
                              <g clip-path="url(#clip-s-Ellipse_18)">\
                                      <ellipse id="s-Ellipse_18" class="ellipse shape non-processed-shape manualfit firer click commentable non-processed" customid="First page" cx="6.5" cy="6.5" rx="6.5" ry="6.5">\
                                      </ellipse>\
                              </g>\
                          </g>\
                          <defs>\
                              <clipPath id="clip-s-Ellipse_18" class="clipPath">\
                                      <ellipse cx="6.5" cy="6.5" rx="6.5" ry="6.5">\
                                      </ellipse>\
                              </clipPath>\
                          </defs>\
                      </svg>\
                      <div class="paddingLayer">\
                          <div id="shapert-s-Ellipse_18" class="content firer" >\
                              <div class="valign">\
                                  <span id="rtr-s-Ellipse_18_0"></span>\
                              </div>\
                          </div>\
                      </div>\
                  </div>\
                  <div id="shapewrapper-s-Ellipse_19" customid="Second page" class="shapewrapper shapewrapper-s-Ellipse_19 non-processed"   datasizewidth="13.0px" datasizeheight="13.0px" datasizewidthpx="13.0" datasizeheightpx="13.0" dataX="456.0" dataY="637.0" >\
                      <div class="backgroundLayer">\
                        <div class="colorLayer"></div>\
                        <div class="imageLayer"></div>\
                      </div>\
                      <svg version="1.1" baseProfile="full" xmlns="http://www.w3.org/2000/svg" id="svg-s-Ellipse_19" class="svgContainer" style="width:100%; height:100%;">\
                          <g>\
                              <g clip-path="url(#clip-s-Ellipse_19)">\
                                      <ellipse id="s-Ellipse_19" class="ellipse shape non-processed-shape manualfit firer click commentable non-processed" customid="Second page" cx="6.5" cy="6.5" rx="6.5" ry="6.5">\
                                      </ellipse>\
                              </g>\
                          </g>\
                          <defs>\
                              <clipPath id="clip-s-Ellipse_19" class="clipPath">\
                                      <ellipse cx="6.5" cy="6.5" rx="6.5" ry="6.5">\
                                      </ellipse>\
                              </clipPath>\
                          </defs>\
                      </svg>\
                      <div class="paddingLayer">\
                          <div id="shapert-s-Ellipse_19" class="content firer" >\
                              <div class="valign">\
                                  <span id="rtr-s-Ellipse_19_0"></span>\
                              </div>\
                          </div>\
                      </div>\
                  </div>\
                </div>\
\
                <div id="s-Browser_10" class="html firer ie-background commentable non-processed" datasizewidth="888.9px" datasizeheight="625.6px" dataX="6.0" dataY="0.0" >\
                  <div class="commentpanel hidden"></div>\
                  <div class="borderLayer">\
                    <iframe class="htmlwidget" srcdoc=\'<html>\
                  <head>\
                    <title></title>\
                    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8"></meta>\
                    <style>\
                        .google-maps {\
                            position: relative;\
                            overflow: hidden;\
                            width: 100% !important;\
                            height: 100% !important;\
                        }\
                        .google-maps iframe {\
                            position: absolute;\
                            top: 0;\
                            left: 0;\
                            width: 100% !important;\
                            height: 100% !important;\
                        }\
                    </style>\
                  </head>\
                <body style="position:absolute; width:100%; height:100%;">  \
                      <div class="google-maps">\
                          <iframe src="https://eugto-datasets-host-fromdrive.on.drv.tw/Bell_RT_initial.html" width="100%" height="450" frameborder="0" style="border:0;" allowfullscreen=""></iframe>\
                      </div>\
                    </body>\
                </html>\
                \' width="100%" height="100%" frameborder="0" marginheight="0px" marginwidth="0px" scrolling="auto" sandbox="allow-scripts allow-same-origin">\
                      <p>Your browser does not support iframes, please update!</p>\
                    </iframe>\
                  </div>\
                </div>\
                </div>\
\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Panel_13" class="panel hidden firer ie-background commentable non-processed" customid="Road Traffic Final"  datasizewidth="900.9px" datasizeheight="657.8px" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
          	<div class="layoutWrapper scrollable">\
          	  <div class="paddingLayer">\
                <div class="freeLayout">\
                <div id="s-Group_25" class="group firer ie-background commentable non-processed" customid="Group 14" datasizewidth="0.0px" datasizeheight="0.0px" >\
                  <div id="shapewrapper-s-Ellipse_20" customid="First page" class="shapewrapper shapewrapper-s-Ellipse_20 non-processed"   datasizewidth="13.0px" datasizeheight="13.0px" datasizewidthpx="13.0" datasizeheightpx="13.0" dataX="437.4" dataY="637.0" >\
                      <div class="backgroundLayer">\
                        <div class="colorLayer"></div>\
                        <div class="imageLayer"></div>\
                      </div>\
                      <svg version="1.1" baseProfile="full" xmlns="http://www.w3.org/2000/svg" id="svg-s-Ellipse_20" class="svgContainer" style="width:100%; height:100%;">\
                          <g>\
                              <g clip-path="url(#clip-s-Ellipse_20)">\
                                      <ellipse id="s-Ellipse_20" class="ellipse shape non-processed-shape manualfit firer click commentable non-processed" customid="First page" cx="6.5" cy="6.5" rx="6.5" ry="6.5">\
                                      </ellipse>\
                              </g>\
                          </g>\
                          <defs>\
                              <clipPath id="clip-s-Ellipse_20" class="clipPath">\
                                      <ellipse cx="6.5" cy="6.5" rx="6.5" ry="6.5">\
                                      </ellipse>\
                              </clipPath>\
                          </defs>\
                      </svg>\
                      <div class="paddingLayer">\
                          <div id="shapert-s-Ellipse_20" class="content firer" >\
                              <div class="valign">\
                                  <span id="rtr-s-Ellipse_20_0"></span>\
                              </div>\
                          </div>\
                      </div>\
                  </div>\
                  <div id="shapewrapper-s-Ellipse_21" customid="Second page" class="shapewrapper shapewrapper-s-Ellipse_21 non-processed"   datasizewidth="13.0px" datasizeheight="13.0px" datasizewidthpx="13.0" datasizeheightpx="13.0" dataX="456.0" dataY="637.0" >\
                      <div class="backgroundLayer">\
                        <div class="colorLayer"></div>\
                        <div class="imageLayer"></div>\
                      </div>\
                      <svg version="1.1" baseProfile="full" xmlns="http://www.w3.org/2000/svg" id="svg-s-Ellipse_21" class="svgContainer" style="width:100%; height:100%;">\
                          <g>\
                              <g clip-path="url(#clip-s-Ellipse_21)">\
                                      <ellipse id="s-Ellipse_21" class="ellipse shape non-processed-shape manualfit firer click commentable non-processed" customid="Second page" cx="6.5" cy="6.5" rx="6.5" ry="6.5">\
                                      </ellipse>\
                              </g>\
                          </g>\
                          <defs>\
                              <clipPath id="clip-s-Ellipse_21" class="clipPath">\
                                      <ellipse cx="6.5" cy="6.5" rx="6.5" ry="6.5">\
                                      </ellipse>\
                              </clipPath>\
                          </defs>\
                      </svg>\
                      <div class="paddingLayer">\
                          <div id="shapert-s-Ellipse_21" class="content firer" >\
                              <div class="valign">\
                                  <span id="rtr-s-Ellipse_21_0"></span>\
                              </div>\
                          </div>\
                      </div>\
                  </div>\
                </div>\
\
                <div id="s-Browser_11" class="html firer ie-background commentable non-processed" datasizewidth="888.9px" datasizeheight="625.6px" dataX="6.0" dataY="0.0" >\
                  <div class="commentpanel hidden"></div>\
                  <div class="borderLayer">\
                    <iframe class="htmlwidget" srcdoc=\'<html>\
                  <head>\
                    <title></title>\
                    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8"></meta>\
                    <style>\
                        .google-maps {\
                            position: relative;\
                            overflow: hidden;\
                            width: 100% !important;\
                            height: 100% !important;\
                        }\
                        .google-maps iframe {\
                            position: absolute;\
                            top: 0;\
                            left: 0;\
                            width: 100% !important;\
                            height: 100% !important;\
                        }\
                    </style>\
                  </head>\
                <body style="position:absolute; width:100%; height:100%;">  \
                      <div class="google-maps">\
                          <iframe src="https://eugto-datasets-host-fromdrive.on.drv.tw/Bell_RT_final.html" width="100%" height="450" frameborder="0" style="border:0;" allowfullscreen=""></iframe>\
                      </div>\
                    </body>\
                </html>\
                \' width="100%" height="100%" frameborder="0" marginheight="0px" marginwidth="0px" scrolling="auto" sandbox="allow-scripts allow-same-origin">\
                      <p>Your browser does not support iframes, please update!</p>\
                    </iframe>\
                  </div>\
                </div>\
                </div>\
\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Panel_8" class="panel hidden firer ie-background commentable non-processed" customid="Generate Map"  datasizewidth="900.9px" datasizeheight="657.8px" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
          	<div class="layoutWrapper scrollable">\
          	  <div class="paddingLayer">\
                <div class="freeLayout">\
                <div id="s-Browser_12" class="html firer ie-background commentable non-processed" datasizewidth="888.9px" datasizeheight="625.6px" dataX="6.0" dataY="0.0" >\
                  <div class="commentpanel hidden"></div>\
                  <div class="borderLayer">\
                    <iframe class="htmlwidget" srcdoc=\'<html>\
                  <head>\
                    <title></title>\
                    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8"></meta>\
                    <style>\
                        .google-maps {\
                            position: relative;\
                            overflow: hidden;\
                            width: 100% !important;\
                            height: 100% !important;\
                        }\
                        .google-maps iframe {\
                            position: absolute;\
                            top: 0;\
                            left: 0;\
                            width: 100% !important;\
                            height: 100% !important;\
                        }\
                    </style>\
                  </head>\
                <body style="position:absolute; width:100%; height:100%;">  \
                      <div class="google-maps">\
                          <iframe src="https://eugto-datasets-host-fromdrive.on.drv.tw/Bell_Blank-map.html" width="100%" height="450" frameborder="0" style="border:0;" allowfullscreen=""></iframe>\
                      </div>\
                    </body>\
                </html>\
                \' width="100%" height="100%" frameborder="0" marginheight="0px" marginwidth="0px" scrolling="auto" sandbox="allow-scripts allow-same-origin">\
                      <p>Your browser does not support iframes, please update!</p>\
                    </iframe>\
                  </div>\
                </div>\
                </div>\
\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Panel_14" class="panel hidden firer ie-background commentable non-processed" customid="AQI Initial "  datasizewidth="900.9px" datasizeheight="657.8px" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
          	<div class="layoutWrapper scrollable">\
          	  <div class="paddingLayer">\
                <div class="freeLayout">\
                <div id="s-Group_14" class="group firer ie-background commentable non-processed" customid="Group 14" datasizewidth="0.0px" datasizeheight="0.0px" >\
                  <div id="shapewrapper-s-Ellipse_1" customid="First page" class="shapewrapper shapewrapper-s-Ellipse_1 non-processed"   datasizewidth="13.0px" datasizeheight="13.0px" datasizewidthpx="13.0" datasizeheightpx="13.0" dataX="437.4" dataY="637.0" >\
                      <div class="backgroundLayer">\
                        <div class="colorLayer"></div>\
                        <div class="imageLayer"></div>\
                      </div>\
                      <svg version="1.1" baseProfile="full" xmlns="http://www.w3.org/2000/svg" id="svg-s-Ellipse_1" class="svgContainer" style="width:100%; height:100%;">\
                          <g>\
                              <g clip-path="url(#clip-s-Ellipse_1)">\
                                      <ellipse id="s-Ellipse_1" class="ellipse shape non-processed-shape manualfit firer click commentable non-processed" customid="First page" cx="6.5" cy="6.5" rx="6.5" ry="6.5">\
                                      </ellipse>\
                              </g>\
                          </g>\
                          <defs>\
                              <clipPath id="clip-s-Ellipse_1" class="clipPath">\
                                      <ellipse cx="6.5" cy="6.5" rx="6.5" ry="6.5">\
                                      </ellipse>\
                              </clipPath>\
                          </defs>\
                      </svg>\
                      <div class="paddingLayer">\
                          <div id="shapert-s-Ellipse_1" class="content firer" >\
                              <div class="valign">\
                                  <span id="rtr-s-Ellipse_1_0"></span>\
                              </div>\
                          </div>\
                      </div>\
                  </div>\
                  <div id="shapewrapper-s-Ellipse_22" customid="Second page" class="shapewrapper shapewrapper-s-Ellipse_22 non-processed"   datasizewidth="13.0px" datasizeheight="13.0px" datasizewidthpx="13.0" datasizeheightpx="13.0" dataX="456.0" dataY="637.0" >\
                      <div class="backgroundLayer">\
                        <div class="colorLayer"></div>\
                        <div class="imageLayer"></div>\
                      </div>\
                      <svg version="1.1" baseProfile="full" xmlns="http://www.w3.org/2000/svg" id="svg-s-Ellipse_22" class="svgContainer" style="width:100%; height:100%;">\
                          <g>\
                              <g clip-path="url(#clip-s-Ellipse_22)">\
                                      <ellipse id="s-Ellipse_22" class="ellipse shape non-processed-shape manualfit firer click commentable non-processed" customid="Second page" cx="6.5" cy="6.5" rx="6.5" ry="6.5">\
                                      </ellipse>\
                              </g>\
                          </g>\
                          <defs>\
                              <clipPath id="clip-s-Ellipse_22" class="clipPath">\
                                      <ellipse cx="6.5" cy="6.5" rx="6.5" ry="6.5">\
                                      </ellipse>\
                              </clipPath>\
                          </defs>\
                      </svg>\
                      <div class="paddingLayer">\
                          <div id="shapert-s-Ellipse_22" class="content firer" >\
                              <div class="valign">\
                                  <span id="rtr-s-Ellipse_22_0"></span>\
                              </div>\
                          </div>\
                      </div>\
                  </div>\
                </div>\
\
                <div id="s-Browser_13" class="html firer ie-background commentable non-processed" datasizewidth="888.9px" datasizeheight="625.6px" dataX="6.0" dataY="0.0" >\
                  <div class="commentpanel hidden"></div>\
                  <div class="borderLayer">\
                    <iframe class="htmlwidget" srcdoc=\'<html>\
                  <head>\
                    <title></title>\
                    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8"></meta>\
                    <style>\
                        .google-maps {\
                            position: relative;\
                            overflow: hidden;\
                            width: 100% !important;\
                            height: 100% !important;\
                        }\
                        .google-maps iframe {\
                            position: absolute;\
                            top: 0;\
                            left: 0;\
                            width: 100% !important;\
                            height: 100% !important;\
                        }\
                    </style>\
                  </head>\
                <body style="position:absolute; width:100%; height:100%;">  \
                      <div class="google-maps">\
                          <iframe src="https://eugto-datasets-host-fromdrive.on.drv.tw/Bell_AQI_initial.html" width="100%" height="450" frameborder="0" style="border:0;" allowfullscreen=""></iframe>\
                      </div>\
                    </body>\
                </html>\
                \' width="100%" height="100%" frameborder="0" marginheight="0px" marginwidth="0px" scrolling="auto" sandbox="allow-scripts allow-same-origin">\
                      <p>Your browser does not support iframes, please update!</p>\
                    </iframe>\
                  </div>\
                </div>\
                </div>\
\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Panel_15" class="panel hidden firer ie-background commentable non-processed" customid="AQI Final"  datasizewidth="900.9px" datasizeheight="657.8px" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
          	<div class="layoutWrapper scrollable">\
          	  <div class="paddingLayer">\
                <div class="freeLayout">\
                <div id="s-Group_26" class="group firer ie-background commentable non-processed" customid="Group 14" datasizewidth="0.0px" datasizeheight="0.0px" >\
                  <div id="shapewrapper-s-Ellipse_23" customid="First page" class="shapewrapper shapewrapper-s-Ellipse_23 non-processed"   datasizewidth="13.0px" datasizeheight="13.0px" datasizewidthpx="13.0" datasizeheightpx="13.0" dataX="437.4" dataY="637.0" >\
                      <div class="backgroundLayer">\
                        <div class="colorLayer"></div>\
                        <div class="imageLayer"></div>\
                      </div>\
                      <svg version="1.1" baseProfile="full" xmlns="http://www.w3.org/2000/svg" id="svg-s-Ellipse_23" class="svgContainer" style="width:100%; height:100%;">\
                          <g>\
                              <g clip-path="url(#clip-s-Ellipse_23)">\
                                      <ellipse id="s-Ellipse_23" class="ellipse shape non-processed-shape manualfit firer click commentable non-processed" customid="First page" cx="6.5" cy="6.5" rx="6.5" ry="6.5">\
                                      </ellipse>\
                              </g>\
                          </g>\
                          <defs>\
                              <clipPath id="clip-s-Ellipse_23" class="clipPath">\
                                      <ellipse cx="6.5" cy="6.5" rx="6.5" ry="6.5">\
                                      </ellipse>\
                              </clipPath>\
                          </defs>\
                      </svg>\
                      <div class="paddingLayer">\
                          <div id="shapert-s-Ellipse_23" class="content firer" >\
                              <div class="valign">\
                                  <span id="rtr-s-Ellipse_23_0"></span>\
                              </div>\
                          </div>\
                      </div>\
                  </div>\
                  <div id="shapewrapper-s-Ellipse_24" customid="Second page" class="shapewrapper shapewrapper-s-Ellipse_24 non-processed"   datasizewidth="13.0px" datasizeheight="13.0px" datasizewidthpx="13.0" datasizeheightpx="13.0" dataX="456.0" dataY="637.0" >\
                      <div class="backgroundLayer">\
                        <div class="colorLayer"></div>\
                        <div class="imageLayer"></div>\
                      </div>\
                      <svg version="1.1" baseProfile="full" xmlns="http://www.w3.org/2000/svg" id="svg-s-Ellipse_24" class="svgContainer" style="width:100%; height:100%;">\
                          <g>\
                              <g clip-path="url(#clip-s-Ellipse_24)">\
                                      <ellipse id="s-Ellipse_24" class="ellipse shape non-processed-shape manualfit firer click commentable non-processed" customid="Second page" cx="6.5" cy="6.5" rx="6.5" ry="6.5">\
                                      </ellipse>\
                              </g>\
                          </g>\
                          <defs>\
                              <clipPath id="clip-s-Ellipse_24" class="clipPath">\
                                      <ellipse cx="6.5" cy="6.5" rx="6.5" ry="6.5">\
                                      </ellipse>\
                              </clipPath>\
                          </defs>\
                      </svg>\
                      <div class="paddingLayer">\
                          <div id="shapert-s-Ellipse_24" class="content firer" >\
                              <div class="valign">\
                                  <span id="rtr-s-Ellipse_24_0"></span>\
                              </div>\
                          </div>\
                      </div>\
                  </div>\
                </div>\
\
                <div id="s-Browser_14" class="html firer ie-background commentable non-processed" datasizewidth="888.9px" datasizeheight="625.6px" dataX="6.0" dataY="0.0" >\
                  <div class="commentpanel hidden"></div>\
                  <div class="borderLayer">\
                    <iframe class="htmlwidget" srcdoc=\'<html>\
                  <head>\
                    <title></title>\
                    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8"></meta>\
                    <style>\
                        .google-maps {\
                            position: relative;\
                            overflow: hidden;\
                            width: 100% !important;\
                            height: 100% !important;\
                        }\
                        .google-maps iframe {\
                            position: absolute;\
                            top: 0;\
                            left: 0;\
                            width: 100% !important;\
                            height: 100% !important;\
                        }\
                    </style>\
                  </head>\
                <body style="position:absolute; width:100%; height:100%;">  \
                      <div class="google-maps">\
                          <iframe src="https://eugto-datasets-host-fromdrive.on.drv.tw/Bell_AQI_final.html" width="100%" height="450" frameborder="0" style="border:0;" allowfullscreen=""></iframe>\
                      </div>\
                    </body>\
                </html>\
                \' width="100%" height="100%" frameborder="0" marginheight="0px" marginwidth="0px" scrolling="auto" sandbox="allow-scripts allow-same-origin">\
                      <p>Your browser does not support iframes, please update!</p>\
                    </iframe>\
                  </div>\
                </div>\
                </div>\
\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Panel_16" class="panel hidden firer ie-background commentable non-processed" customid="Waste Generation Initial "  datasizewidth="900.9px" datasizeheight="657.8px" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
          	<div class="layoutWrapper scrollable">\
          	  <div class="paddingLayer">\
                <div class="freeLayout">\
                <div id="s-Group_27" class="group firer ie-background commentable non-processed" customid="Group 14" datasizewidth="0.0px" datasizeheight="0.0px" >\
                  <div id="shapewrapper-s-Ellipse_25" customid="First page" class="shapewrapper shapewrapper-s-Ellipse_25 non-processed"   datasizewidth="13.0px" datasizeheight="13.0px" datasizewidthpx="13.0" datasizeheightpx="13.0" dataX="437.4" dataY="637.0" >\
                      <div class="backgroundLayer">\
                        <div class="colorLayer"></div>\
                        <div class="imageLayer"></div>\
                      </div>\
                      <svg version="1.1" baseProfile="full" xmlns="http://www.w3.org/2000/svg" id="svg-s-Ellipse_25" class="svgContainer" style="width:100%; height:100%;">\
                          <g>\
                              <g clip-path="url(#clip-s-Ellipse_25)">\
                                      <ellipse id="s-Ellipse_25" class="ellipse shape non-processed-shape manualfit firer click commentable non-processed" customid="First page" cx="6.5" cy="6.5" rx="6.5" ry="6.5">\
                                      </ellipse>\
                              </g>\
                          </g>\
                          <defs>\
                              <clipPath id="clip-s-Ellipse_25" class="clipPath">\
                                      <ellipse cx="6.5" cy="6.5" rx="6.5" ry="6.5">\
                                      </ellipse>\
                              </clipPath>\
                          </defs>\
                      </svg>\
                      <div class="paddingLayer">\
                          <div id="shapert-s-Ellipse_25" class="content firer" >\
                              <div class="valign">\
                                  <span id="rtr-s-Ellipse_25_0"></span>\
                              </div>\
                          </div>\
                      </div>\
                  </div>\
                  <div id="shapewrapper-s-Ellipse_26" customid="Second page" class="shapewrapper shapewrapper-s-Ellipse_26 non-processed"   datasizewidth="13.0px" datasizeheight="13.0px" datasizewidthpx="13.0" datasizeheightpx="13.0" dataX="456.0" dataY="637.0" >\
                      <div class="backgroundLayer">\
                        <div class="colorLayer"></div>\
                        <div class="imageLayer"></div>\
                      </div>\
                      <svg version="1.1" baseProfile="full" xmlns="http://www.w3.org/2000/svg" id="svg-s-Ellipse_26" class="svgContainer" style="width:100%; height:100%;">\
                          <g>\
                              <g clip-path="url(#clip-s-Ellipse_26)">\
                                      <ellipse id="s-Ellipse_26" class="ellipse shape non-processed-shape manualfit firer click commentable non-processed" customid="Second page" cx="6.5" cy="6.5" rx="6.5" ry="6.5">\
                                      </ellipse>\
                              </g>\
                          </g>\
                          <defs>\
                              <clipPath id="clip-s-Ellipse_26" class="clipPath">\
                                      <ellipse cx="6.5" cy="6.5" rx="6.5" ry="6.5">\
                                      </ellipse>\
                              </clipPath>\
                          </defs>\
                      </svg>\
                      <div class="paddingLayer">\
                          <div id="shapert-s-Ellipse_26" class="content firer" >\
                              <div class="valign">\
                                  <span id="rtr-s-Ellipse_26_0"></span>\
                              </div>\
                          </div>\
                      </div>\
                  </div>\
                </div>\
\
                <div id="s-Browser_15" class="html firer ie-background commentable non-processed" datasizewidth="888.9px" datasizeheight="625.6px" dataX="6.0" dataY="0.0" >\
                  <div class="commentpanel hidden"></div>\
                  <div class="borderLayer">\
                    <iframe class="htmlwidget" srcdoc=\'<html>\
                  <head>\
                    <title></title>\
                    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8"></meta>\
                    <style>\
                        .google-maps {\
                            position: relative;\
                            overflow: hidden;\
                            width: 100% !important;\
                            height: 100% !important;\
                        }\
                        .google-maps iframe {\
                            position: absolute;\
                            top: 0;\
                            left: 0;\
                            width: 100% !important;\
                            height: 100% !important;\
                        }\
                    </style>\
                  </head>\
                <body style="position:absolute; width:100%; height:100%;">  \
                      <div class="google-maps">\
                          <iframe src="https://eugto-datasets-host-fromdrive.on.drv.tw/Bell_WG_initial.html" width="100%" height="450" frameborder="0" style="border:0;" allowfullscreen=""></iframe>\
                      </div>\
                    </body>\
                </html>\
                \' width="100%" height="100%" frameborder="0" marginheight="0px" marginwidth="0px" scrolling="auto" sandbox="allow-scripts allow-same-origin">\
                      <p>Your browser does not support iframes, please update!</p>\
                    </iframe>\
                  </div>\
                </div>\
                </div>\
\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Panel_17" class="panel hidden firer ie-background commentable non-processed" customid="Waste Generation Final"  datasizewidth="900.9px" datasizeheight="657.8px" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
          	<div class="layoutWrapper scrollable">\
          	  <div class="paddingLayer">\
                <div class="freeLayout">\
                <div id="s-Group_28" class="group firer ie-background commentable non-processed" customid="Group 14" datasizewidth="0.0px" datasizeheight="0.0px" >\
                  <div id="shapewrapper-s-Ellipse_27" customid="First page" class="shapewrapper shapewrapper-s-Ellipse_27 non-processed"   datasizewidth="13.0px" datasizeheight="13.0px" datasizewidthpx="13.0" datasizeheightpx="13.0" dataX="437.4" dataY="637.0" >\
                      <div class="backgroundLayer">\
                        <div class="colorLayer"></div>\
                        <div class="imageLayer"></div>\
                      </div>\
                      <svg version="1.1" baseProfile="full" xmlns="http://www.w3.org/2000/svg" id="svg-s-Ellipse_27" class="svgContainer" style="width:100%; height:100%;">\
                          <g>\
                              <g clip-path="url(#clip-s-Ellipse_27)">\
                                      <ellipse id="s-Ellipse_27" class="ellipse shape non-processed-shape manualfit firer click commentable non-processed" customid="First page" cx="6.5" cy="6.5" rx="6.5" ry="6.5">\
                                      </ellipse>\
                              </g>\
                          </g>\
                          <defs>\
                              <clipPath id="clip-s-Ellipse_27" class="clipPath">\
                                      <ellipse cx="6.5" cy="6.5" rx="6.5" ry="6.5">\
                                      </ellipse>\
                              </clipPath>\
                          </defs>\
                      </svg>\
                      <div class="paddingLayer">\
                          <div id="shapert-s-Ellipse_27" class="content firer" >\
                              <div class="valign">\
                                  <span id="rtr-s-Ellipse_27_0"></span>\
                              </div>\
                          </div>\
                      </div>\
                  </div>\
                  <div id="shapewrapper-s-Ellipse_28" customid="Second page" class="shapewrapper shapewrapper-s-Ellipse_28 non-processed"   datasizewidth="13.0px" datasizeheight="13.0px" datasizewidthpx="13.0" datasizeheightpx="13.0" dataX="456.0" dataY="637.0" >\
                      <div class="backgroundLayer">\
                        <div class="colorLayer"></div>\
                        <div class="imageLayer"></div>\
                      </div>\
                      <svg version="1.1" baseProfile="full" xmlns="http://www.w3.org/2000/svg" id="svg-s-Ellipse_28" class="svgContainer" style="width:100%; height:100%;">\
                          <g>\
                              <g clip-path="url(#clip-s-Ellipse_28)">\
                                      <ellipse id="s-Ellipse_28" class="ellipse shape non-processed-shape manualfit firer click commentable non-processed" customid="Second page" cx="6.5" cy="6.5" rx="6.5" ry="6.5">\
                                      </ellipse>\
                              </g>\
                          </g>\
                          <defs>\
                              <clipPath id="clip-s-Ellipse_28" class="clipPath">\
                                      <ellipse cx="6.5" cy="6.5" rx="6.5" ry="6.5">\
                                      </ellipse>\
                              </clipPath>\
                          </defs>\
                      </svg>\
                      <div class="paddingLayer">\
                          <div id="shapert-s-Ellipse_28" class="content firer" >\
                              <div class="valign">\
                                  <span id="rtr-s-Ellipse_28_0"></span>\
                              </div>\
                          </div>\
                      </div>\
                  </div>\
                </div>\
\
                <div id="s-Browser_16" class="html firer ie-background commentable non-processed" datasizewidth="888.9px" datasizeheight="625.6px" dataX="6.0" dataY="0.0" >\
                  <div class="commentpanel hidden"></div>\
                  <div class="borderLayer">\
                    <iframe class="htmlwidget" srcdoc=\'<html>\
                  <head>\
                    <title></title>\
                    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8"></meta>\
                    <style>\
                        .google-maps {\
                            position: relative;\
                            overflow: hidden;\
                            width: 100% !important;\
                            height: 100% !important;\
                        }\
                        .google-maps iframe {\
                            position: absolute;\
                            top: 0;\
                            left: 0;\
                            width: 100% !important;\
                            height: 100% !important;\
                        }\
                    </style>\
                  </head>\
                <body style="position:absolute; width:100%; height:100%;">  \
                      <div class="google-maps">\
                          <iframe src="https://eugto-datasets-host-fromdrive.on.drv.tw/Bell_WG_final.html" width="100%" height="450" frameborder="0" style="border:0;" allowfullscreen=""></iframe>\
                      </div>\
                    </body>\
                </html>\
                \' width="100%" height="100%" frameborder="0" marginheight="0px" marginwidth="0px" scrolling="auto" sandbox="allow-scripts allow-same-origin">\
                      <p>Your browser does not support iframes, please update!</p>\
                    </iframe>\
                  </div>\
                </div>\
                </div>\
\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Button_1" class="button multiline manualfit firer click commentable non-processed" customid="Generate"   datasizewidth="93.0px" datasizeheight="44.0px" dataX="619.5" dataY="144.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Button_1_0">Generate</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>  \
</div>\
';
document.getElementById("chromeTransfer").innerHTML = content;